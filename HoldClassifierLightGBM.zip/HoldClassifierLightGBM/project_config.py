import copy
import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG: dict[str, Any] = {
    "storage": {
        "account_name": "stslalightgbmuateu",
        "default_container": "train-data",
    },
    "training": {
        "hold_minutes_col": "HoldTimeInMinutes",
        "model_prefix": "hold-classifier-model/",
        "training_data_prefix": "hold-classifier-training-data/",
    },
    "inference": {
        "threshold": 0.5,
    },
    "paths": {
        "local_data_dir": "classifier/local-data",
        "default_local_training_csv": "classifier/local-data/Cases_CompleteSet_ActualTime.csv",
    },
    "identity": {
        "default_uami_client_id": "89ab0e3a-79c6-4737-8946-e6e7bbda01c0",
    },
    "model": {
        "random_state": 42,
    },
    "features": {
        "preferred": [
            "msdyn_casetypeidname",
            "msdyn_casesubtypeidname",
            "msdyn_casereasonidname",
            "msdyn_casesubreasonidname",
            "msdyn_complexityname",
            "prioritycodename",
            "msdyn_businessfunctionidname",
            "msdyn_countrysubmitteridname",
            "msdyn_caserocname",
            "msdyn_lineofbusinessidname",
            "msdyn_programidname",
            "msdyn_countryprocessedidname",
        ]
    },
}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _candidate_config_paths() -> list[Path]:
    explicit = os.getenv("HOLD_CLASSIFIER_CONFIG_PATH")
    here = Path(__file__).resolve().parent
    paths: list[Path] = []
    if explicit:
        paths.append(Path(explicit))
    paths.append(here / "config.yaml")
    return paths


@lru_cache(maxsize=1)
def get_config() -> dict[str, Any]:
    config = copy.deepcopy(DEFAULT_CONFIG)
    for path in _candidate_config_paths():
        if not path.exists():
            continue
        loaded = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if isinstance(loaded, dict):
            config = _deep_merge(config, loaded)
            break
    return config


def cfg_get(path: str, default: Any = None) -> Any:
    cur: Any = get_config()
    for token in path.split("."):
        if not isinstance(cur, dict) or token not in cur:
            return default
        cur = cur[token]
    return cur

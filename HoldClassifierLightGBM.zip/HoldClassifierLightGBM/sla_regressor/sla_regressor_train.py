from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from pandas.api.types import is_categorical_dtype, is_object_dtype, is_string_dtype
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, train_test_split


def kfold_target_encode(
    df: pd.DataFrame,
    *,
    cols: list[str],
    target: str,
    n_splits: int,
    random_state: int,
) -> pd.DataFrame:
    df = df.copy()
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    global_mean = df[target].mean()
    for col in cols:
        enc_col = f"{col}_encoded"
        df[enc_col] = np.nan
        for train_idx, val_idx in kf.split(df):
            means = df.iloc[train_idx].groupby(col)[target].mean()
            df.loc[df.index[val_idx], enc_col] = df.iloc[val_idx][col].map(means)
        df[enc_col] = df[enc_col].fillna(global_mean)
    return df


def build_encodings(df: pd.DataFrame, *, cols: list[str], target: str) -> Dict[str, Any]:
    enc: Dict[str, Any] = {}
    global_mean = float(df[target].mean())
    for col in cols:
        mapping = df.groupby(col)[target].mean().to_dict()
        enc[col] = {"mapping": mapping, "global_mean": global_mean}
    return {"columns": enc}


@dataclass(frozen=True)
class TrainArtifacts:
    model: lgb.LGBMRegressor
    peaks: Dict[str, Any]
    encodings: Dict[str, Any]
    metrics: Dict[str, Any]
    feature_columns: list[str]
    target_encode_cols: list[str]


def train_from_cleaned(df: pd.DataFrame, cfg: Dict[str, Any]) -> TrainArtifacts:
    """
    Train resolution-time Tweedie LightGBM model on a cleaned dataframe that contains:
      - createdon, msdyn_resolveddate
      - case_time_minutes (target, resolution minus hold)
    """
    training = cfg["training"]
    test_size = float(training["test_size"])
    random_state = int(training["random_state"])
    kfold_splits = int(training["kfold_splits"])
    tweedie_power = float(training["tweedie_variance_power"])
    n_estimators = int(training["n_estimators"])
    learning_rate = float(training["learning_rate"])
    num_leaves = int(training["num_leaves"])
    min_data_in_leaf = int(training["min_data_in_leaf"])
    bagging_fraction = float(training["bagging_fraction"])
    bagging_freq = int(training.get("bagging_freq", 0))
    feature_fraction = float(training["feature_fraction"])
    lambda_l1 = float(training.get("lambda_l1", 0.0))
    lambda_l2 = float(training.get("lambda_l2", 0.0))
    target_encode_cols = list(training["target_encode_cols"])
    id_candidates = list(training["id_candidates"])
    required_roc_column = str(training["required_roc_column"])
    feature_columns = list(training["required_feature_columns"])

    df = df.copy()

    df["createdon"] = pd.to_datetime(df["createdon"])
    df["hour_of_day"] = df["createdon"].dt.hour
    df["day_of_week"] = df["createdon"].dt.dayofweek
    df["is_weekend"] = (df["day_of_week"] // 5).astype(int)
    df["hour_sin"] = np.sin(2 * np.pi * df["hour_of_day"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour_of_day"] / 24)
    df["day_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["day_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7)

    def _shift(row) -> str:
        if row["is_weekend"] == 1:
            return "Weekend"
        if 8 <= row["hour_of_day"] <= 18:
            return "Weekday_Business_Hours"
        return "Weekday_After_Hours"

    df["shift_type"] = df.apply(_shift, axis=1)

    peaks: Dict[str, Any] = {}
    if "msdyn_countryprocessedidname" in df.columns:
        peak_analysis = (
            df.groupby(["msdyn_countryprocessedidname", "hour_of_day"])["case_time_minutes"]
            .median()
            .reset_index()
        )
        idx = (
            peak_analysis.groupby(["msdyn_countryprocessedidname"])["case_time_minutes"].transform("max")
            == peak_analysis["case_time_minutes"]
        )
        country_peaks = peak_analysis[idx].rename(columns={"hour_of_day": "peak_hour"})
        peaks = country_peaks.set_index("msdyn_countryprocessedidname")["peak_hour"].to_dict()
        df["peak_hour"] = df["msdyn_countryprocessedidname"].map(peaks)

        def _hour_dist(h1: float, h2: float) -> float:
            if pd.isna(h1) or pd.isna(h2):
                return float("nan")
            diff = abs(h1 - h2)
            return min(diff, 24 - diff)

        df["dist_from_country_peak"] = df.apply(
            lambda r: _hour_dist(r["hour_of_day"], r["peak_hour"]), axis=1
        )
    else:
        df["dist_from_country_peak"] = np.nan

    # Backlog density (4h/24h)
    df_sorted = df.sort_values("createdon").copy()
    id_col: Optional[str] = None
    for candidate in id_candidates:
        if candidate in df_sorted.columns:
            id_col = candidate
            break
    if id_col is None:
        df_sorted["_tmp_id"] = 1
        id_col = "_tmp_id"

    created_ts = pd.to_datetime(df_sorted["createdon"])
    id_series = df_sorted[id_col].fillna(0)
    counts_4h = pd.Series(id_series.values, index=created_ts).rolling("4h").count().fillna(0)
    counts_24h = pd.Series(id_series.values, index=created_ts).rolling("24h").count().fillna(0)
    df.loc[df_sorted.index, "backlog_4h"] = counts_4h.values
    df.loc[df_sorted.index, "backlog_24h"] = counts_24h.values

    df["backlog_weekend_interaction"] = df["backlog_24h"] * df["is_weekend"]
    df["is_friday_afternoon"] = ((df["day_of_week"] == 4) & (df["hour_of_day"] >= 15)).astype(int)
    df["friday_rush_interaction"] = df["backlog_4h"] * df["is_friday_afternoon"]

    if required_roc_column not in df.columns:
        raise ValueError(f"{required_roc_column} is required for training but not present in the data.")

    df = kfold_target_encode(
        df,
        cols=target_encode_cols,
        target="case_time_minutes",
        n_splits=kfold_splits,
        random_state=random_state,
    )
    df["reason_weekend_interaction"] = df["msdyn_casesubreasonidname_encoded"] * df["is_weekend"]

    missing = [c for c in feature_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required feature columns: {missing}")

    upper_limit = float(df["case_time_minutes"].quantile(0.95))
    df_clipped = df[df["case_time_minutes"] <= upper_limit].copy()

    X = df_clipped[feature_columns].copy()
    y = df_clipped["case_time_minutes"]

    for col in feature_columns:
        s = X[col]
        if is_object_dtype(s) or is_string_dtype(s) or is_categorical_dtype(s):
            s_str = s.astype("string")
            cats = sorted(s_str.dropna().unique().tolist())
            X[col] = s_str.astype("category").cat.set_categories(cats)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    model = lgb.LGBMRegressor(
        objective="tweedie",
        tweedie_variance_power=tweedie_power,
        n_estimators=n_estimators,
        learning_rate=learning_rate,
        num_leaves=num_leaves,
        min_data_in_leaf=min_data_in_leaf,
        bagging_fraction=bagging_fraction,
        bagging_freq=bagging_freq,
        feature_fraction=feature_fraction,
        reg_alpha=lambda_l1,
        reg_lambda=lambda_l2,
        random_state=random_state,
        n_jobs=-1,
        verbose=-1,
    )
    model.fit(
        X_train,
        y_train,
        eval_set=[(X_test, y_test)],
        eval_metric="tweedie",
        callbacks=[lgb.early_stopping(stopping_rounds=50)],
    )
    y_pred = model.predict(X_test)

    metrics = {
        "trained_rows": int(len(X)),
        "upper_clip_minutes_p95": upper_limit,
        "mae_minutes": float(mean_absolute_error(y_test, y_pred)),
        "r2_minutes": float(r2_score(y_test, y_pred)),
    }

    encodings = build_encodings(df_clipped, cols=target_encode_cols, target="case_time_minutes")

    return TrainArtifacts(
        model=model,
        peaks=peaks,
        encodings=encodings,
        metrics=metrics,
        feature_columns=feature_columns,
        target_encode_cols=target_encode_cols,
    )


def write_artifacts(out_dir: Path, artifacts: TrainArtifacts) -> Dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = out_dir / "model.pkl"
    peaks_path = out_dir / "peaks.pkl"
    enc_path = out_dir / "encodings.pkl"
    metrics_path = out_dir / "metrics.json"

    joblib.dump(artifacts.model, model_path)
    joblib.dump(artifacts.peaks, peaks_path)
    joblib.dump(artifacts.encodings, enc_path)
    metrics_path.write_text(json.dumps(artifacts.metrics, indent=2), encoding="utf-8")

    return {
        "model": model_path,
        "peaks": peaks_path,
        "encodings": enc_path,
        "metrics": metrics_path,
    }


from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Tuple

import pandas as pd
from zipfile import BadZipFile

import numpy as np

from project_config import get_config, cfg_get


def load_config() -> Dict[str, Any]:
    """
    Load the regressor config from the unified project `config.yaml` (top-level),
    under the `sla_regressor:` key.
    """
    unified = get_config()
    # Back-compat: older config used `regressor:` as the key.
    reg = unified.get("sla_regressor") or unified.get("regressor")
    if not isinstance(reg, dict) or not reg:
        raise FileNotFoundError(
            "Missing SLA regressor config. Expected a non-empty `sla_regressor:` section in the unified project config.yaml."
        )
    return reg


def load_table(path: Path) -> pd.DataFrame:
    """
    Load CSV/XLSX into a dataframe.
    """
    suffix = str(path).lower()
    if suffix.endswith(".xlsx"):
        try:
            return pd.read_excel(path, engine="openpyxl")
        except BadZipFile:
            # Common case: file is actually .xls (or not a real xlsx) but named .xlsx.
            try:
                return pd.read_excel(path, engine="xlrd")
            except Exception as exc:
                raise ValueError(
                    "Input looks like it is not a valid .xlsx file (openpyxl: 'File is not a zip file'). "
                    "If this is an old Excel file, use a real .xls extension or convert to .xlsx."
                ) from exc
    if suffix.endswith(".xls"):
        try:
            return pd.read_excel(path, engine="xlrd")
        except ImportError as exc:
            raise ValueError(
                "Reading .xls requires 'xlrd>=2.0.1'. Convert the file to .xlsx or install xlrd."
            ) from exc
        except BadZipFile as exc:
            raise ValueError(
                "Input looks like it is not a valid .xls file. If this file is actually .xlsx, "
                "rename it to .xlsx and retry."
            ) from exc
    return pd.read_csv(path)


@dataclass(frozen=True)
class ProcessStats:
    raw_rows: int
    after_date: int
    after_resolution: int
    after_null_drop: int
    below_min: int
    above_max: int


def _coerce_hold_minutes(series: pd.Series) -> pd.Series:
    # Prefer numeric minutes; fall back to parsing simple duration strings when present.
    s_num = pd.to_numeric(series, errors="coerce")
    if s_num.notna().any():
        return s_num
    s = series.fillna("").astype(str)
    # Handle "Xd Yh Zm" or "X d Y h Z m" forms.
    s = s.str.replace(r"(\d+)\s*d", r"\1D", regex=True)
    s = s.str.replace(r"(\d+)\s*h", r"\1h", regex=True)
    s = s.str.replace(r"(\d+)\s*m", r"\1min", regex=True)
    td = pd.to_timedelta(s, errors="coerce")
    return td.dt.total_seconds() / 60.0


def _coerce_case_time_minutes(series: pd.Series) -> pd.Series:
    # Prefer numeric minutes; fall back to parsing duration strings.
    s_num = pd.to_numeric(series, errors="coerce")
    if s_num.notna().any():
        return s_num
    s = series.fillna("").astype(str)
    s = s.str.replace(r"(\d+)\s*d", r"\1D", regex=True)
    s = s.str.replace(r"(\d+)\s*h", r"\1h", regex=True)
    s = s.str.replace(r"(\d+)\s*m", r"\1min", regex=True)
    td = pd.to_timedelta(s, errors="coerce")
    return td.dt.total_seconds() / 60.0


def process_raw_file(path: Path, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, ProcessStats]:
    """
    Process raw training data:
    - parse dates
    - date_range filter
    - compute resolution_minutes target (resolved - created)
    - compute case_time_minutes target (resolution_minutes - hold_minutes)
    - apply thresholds to case_time_minutes
    - drop nulls only for core timestamp fields (keep partially-filled rows)
    """
    df = load_table(path)
    raw_rows = len(df)

    df = df.copy()
    df["createdon"] = pd.to_datetime(df["createdon"], errors="coerce")
    df["msdyn_resolveddate"] = pd.to_datetime(df["msdyn_resolveddate"], errors="coerce")

    dr = cfg["data"]["date_range"]
    start = pd.to_datetime(dr["start_date"])
    end = pd.to_datetime(dr["end_date"])
    if start > end:
        raise ValueError("config.yaml date_range.start_date must be <= end_date")

    mask_date = (df["createdon"] >= start) & (df["createdon"] <= end)
    df = df.loc[mask_date].copy()
    after_date = len(df)
    if df.empty:
        raise ValueError("No rows remain after date_range filter")

    time_delta = df["msdyn_resolveddate"] - df["createdon"]
    resolution_minutes = time_delta.dt.total_seconds() / 60.0
    df["resolution_minutes"] = resolution_minutes

    # Prefer a precomputed case-time column if present.
    # Your dataset includes `ActualCaseTimeinMinutes`, which is already the intended target.
    case_time_col = str(cfg_get("sla_regressor.data.case_time_minutes_col", "ActualCaseTimeinMinutes"))
    if case_time_col in df.columns:
        df["case_time_minutes"] = _coerce_case_time_minutes(df[case_time_col])
    else:
        # Fallback: compute "active" case time (exclude hold time).
        hold_minutes_col = str(cfg_get("training.hold_minutes_col", "HoldTimeInMinutes"))
        if hold_minutes_col in df.columns:
            hold_minutes = _coerce_hold_minutes(df[hold_minutes_col]).fillna(0.0)
        elif "onholdtime" in df.columns:
            hold_minutes = _coerce_hold_minutes(df["onholdtime"]).fillna(0.0)
        else:
            hold_minutes = pd.Series(np.zeros(len(df), dtype=float), index=df.index)
        df["hold_minutes"] = hold_minutes
        df["case_time_minutes"] = (df["resolution_minutes"] - df["hold_minutes"]).clip(lower=0.0)

    thresholds = cfg.get("thresholds", {})
    days = float(thresholds.get("days_cutoff", 0) or 0)
    hours = float(thresholds.get("hours_cutoff", 0) or 0)
    min_mins = float(thresholds.get("min_resolution_minutes", 0) or 0)
    max_mins = days * 24 * 60 + hours * 60

    below_min = int((df["case_time_minutes"] < min_mins).sum())
    above_max = int((df["case_time_minutes"] > max_mins).sum())

    mask_resolution = (df["case_time_minutes"] >= min_mins) & (df["case_time_minutes"] <= max_mins)
    df = df.loc[mask_resolution].copy()
    after_resolution = len(df)
    if df.empty:
        raise ValueError("No rows remain after resolution threshold filter")

    # Keep rows even if many fields are null; require timestamps and target.
    df = df.dropna(subset=["createdon", "msdyn_resolveddate", "case_time_minutes"]).copy()
    after_null = len(df)
    if df.empty:
        raise ValueError("No rows remain after null-drop (createdon/resolveddate)")

    stats = ProcessStats(
        raw_rows=raw_rows,
        after_date=after_date,
        after_resolution=after_resolution,
        after_null_drop=after_null,
        below_min=below_min,
        above_max=above_max,
    )
    return df, stats


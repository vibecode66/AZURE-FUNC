"""
Inference logic for the resolution-time Tweedie LightGBM model.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from pandas.api.types import is_categorical_dtype, is_object_dtype, is_string_dtype

from sla_regressor.sla_regressor_process_data import load_config


def get_hour_dist(h1, h2) -> float:
    # Match cosmic behavior: default to 12 hours when missing.
    if pd.isna(h1) or pd.isna(h2):
        return 12
    diff = abs(h1 - h2)
    return min(diff, 24 - diff)


def load_table(path: str) -> pd.DataFrame:
    if str(path).lower().endswith((".xls", ".xlsx")):
        return pd.read_excel(path)
    return pd.read_csv(path)


@dataclass(frozen=True)
class InferenceArtifacts:
    model: Any
    peaks: Dict[str, Any]
    encodings: Dict[str, Any]
    feature_columns: list[str]
    target_encode_cols: list[str]
    id_candidates: list[str]


def _is_numeric_feature(col: str) -> bool:
    # Numeric engineered features in the pipeline
    if col.endswith("_encoded"):
        return True
    return col in {
        "dist_from_country_peak",
        "hour_sin",
        "hour_cos",
        "day_sin",
        "day_cos",
        "backlog_4h",
        "backlog_24h",
        "reason_weekend_interaction",
        "backlog_weekend_interaction",
        "friday_rush_interaction",
    }


def artifacts_from_objects(
    model: Any,
    peaks: Dict[str, Any],
    encodings: Dict[str, Any],
    cfg: Optional[Dict[str, Any]] = None,
) -> InferenceArtifacts:
    cfg = cfg or load_config()
    feature_columns = list(cfg["training"]["required_feature_columns"])
    target_encode_cols = list(cfg["training"]["target_encode_cols"])
    id_candidates = list(cfg["training"]["id_candidates"])
    return InferenceArtifacts(
        model=model,
        peaks=peaks,
        encodings=encodings,
        feature_columns=feature_columns,
        target_encode_cols=target_encode_cols,
        id_candidates=id_candidates,
    )


def artifacts_from_files(
    model_path: str,
    peaks_path: str,
    encodings_path: str,
    cfg: Optional[Dict[str, Any]] = None,
) -> InferenceArtifacts:
    model = joblib.load(model_path)
    peaks = joblib.load(peaks_path)
    encodings = joblib.load(encodings_path)
    return artifacts_from_objects(model, peaks, encodings, cfg=cfg)


def predict_df(df: pd.DataFrame, artifacts: InferenceArtifacts) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns:
      - out_df: columns ['case_id', 'predicted_resolution_dt']
      - full_df: original df with prediction columns appended (for debugging/inspection)
    """
    df = df.copy()

    # Temporal + cyclic features
    df["createdon"] = pd.to_datetime(df["createdon"])
    df["hour_of_day"] = df["createdon"].dt.hour
    df["day_of_week"] = df["createdon"].dt.dayofweek
    df["is_weekend"] = (df["day_of_week"] // 5).astype(int)
    df["shift_type"] = df.apply(
        lambda row: "Weekend"
        if row["is_weekend"] == 1
        else ("Weekday_Business_Hours" if 8 <= row["hour_of_day"] <= 18 else "Weekday_After_Hours"),
        axis=1,
    )
    df["hour_sin"] = np.sin(2 * np.pi * df["hour_of_day"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour_of_day"] / 24)
    df["day_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["day_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7)

    # Distance from peak per country
    df["peak_hour"] = df["msdyn_countryprocessedidname"].map(artifacts.peaks)
    df["dist_from_country_peak"] = df.apply(
        lambda row: get_hour_dist(row["hour_of_day"], row["peak_hour"]), axis=1
    )

    # Backlog density (4h/24h) using createdon order
    df_sorted = df.sort_values("createdon").copy()
    id_col: Optional[str] = None
    for candidate in artifacts.id_candidates:
        if candidate in df_sorted.columns:
            id_col = candidate
            break
    if id_col is None:
        df_sorted["_tmp_id"] = 1
        id_col = "_tmp_id"
    created_ts = pd.to_datetime(df_sorted["createdon"])
    id_series = df_sorted[id_col].fillna(0)
    counts_4h = pd.Series(id_series.values, index=created_ts).rolling("4h").count().fillna(0)
    counts_24h = pd.Series(id_series.values, index=created_ts).rolling("24h").count().fillna(0)
    df.loc[df_sorted.index, "backlog_4h"] = counts_4h.values
    df.loc[df_sorted.index, "backlog_24h"] = counts_24h.values
    if "_tmp_id" in df_sorted.columns:
        df_sorted = df_sorted.drop(columns=["_tmp_id"])

    # Weekend/backlog interactions (align with training)
    df["backlog_weekend_interaction"] = df["backlog_24h"] * df["is_weekend"]
    df["is_friday_afternoon"] = ((df["day_of_week"] == 4) & (df["hour_of_day"] >= 15)).astype(int)
    df["friday_rush_interaction"] = df["backlog_4h"] * df["is_friday_afternoon"]

    # Apply saved target encodings (global means from training).
    enc_cols = artifacts.encodings["columns"]
    for col in artifacts.target_encode_cols:
        enc_col = f"{col}_encoded"
        col_enc = enc_cols.get(col)
        if col_enc is None:
            raise KeyError(f"Missing encoding for column {col} in encodings file")
        mapping = col_enc["mapping"]
        global_mean = col_enc["global_mean"]
        df[enc_col] = df[col].map(mapping)
        df[enc_col] = df[enc_col].fillna(global_mean)

    # Interaction feature from training
    df["reason_weekend_interaction"] = df["msdyn_casesubreasonidname_encoded"] * df["is_weekend"]

    # Ensure all required columns exist
    for col in artifacts.feature_columns:
        if col not in df.columns:
            # Important: if a column was categorical during training, defaulting to 0 (numeric)
            # can cause LightGBM to see a different categorical_feature set and error.
            df[col] = 0 if _is_numeric_feature(col) else "Unknown"

    X = df[artifacts.feature_columns].copy()

    # Categorical alignment
    for col in X.columns:
        s = X[col]
        # Match training-side handling (and protect against pandas "string" dtype):
        if is_object_dtype(s) or is_string_dtype(s) or is_categorical_dtype(s):
            s_str = s.astype("string")
            X[col] = s_str.astype("category")

    # Predict (Tweedie model trained on case_time_minutes)
    df["predicted_resolution_minutes"] = artifacts.model.predict(X)
    # Back-compat alias: the model predicts "case time" (excluding hold).
    df["predicted_case_time_minutes"] = df["predicted_resolution_minutes"]
    df["predicted_duration_h_m"] = df["predicted_resolution_minutes"].apply(
        lambda x: f"{int(x // 60)}h {int(x % 60)}m"
    )
    df["predicted_resolution_dt"] = df.apply(
        lambda row: (
            (
                row["createdon"]
                + pd.to_timedelta(row["predicted_resolution_minutes"], unit="m")
            ).strftime("%Y-%m-%d %H:%M:%S")
            if pd.notnull(row["createdon"])
            else ""
        ),
        axis=1,
    )
    df["predicted_case_time_dt"] = df["predicted_resolution_dt"]

    # Build output with case id and predicted datetime.
    out_id_col = next((c for c in artifacts.id_candidates if c in df.columns), None)
    if out_id_col is None:
        raise ValueError(
            f"None of the ID candidates {artifacts.id_candidates} found in input data."
        )
    out_df = df[[out_id_col, "predicted_resolution_dt"]].copy()
    out_df.columns = ["case_id", "predicted_resolution_dt"]

    return out_df, df


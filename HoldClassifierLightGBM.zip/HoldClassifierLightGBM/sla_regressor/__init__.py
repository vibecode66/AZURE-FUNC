"""
SLA regression (resolution-time) Azure Functions components.

This folder was previously a standalone Function App. It now lives under the main
Function App and is organized into:
- `sla_regressor_process_data.py`
- `sla_regressor_train.py`
- `sla_regressor_infer.py`
"""


import datetime
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Optional

import azure.functions as func
import joblib
import pandas as pd

from project_config import cfg_get
from sla_regressor.sla_regressor_infer import (
    artifacts_from_files,
    artifacts_from_objects,
    load_table as infer_load_table,
    predict_df,
)
from sla_regressor.sla_regressor_process_data import (
    load_config,
    process_raw_file,
)
from sla_regressor.sla_regressor_train import train_from_cleaned, write_artifacts
from blob_io import download_blob_to_file, latest_blob, upload_file_to_blob


def _json_response(obj: dict[str, Any], status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(obj),
        status_code=status_code,
        mimetype="application/json",
    )


def _is_azure_runtime() -> bool:
    return bool(os.getenv("WEBSITE_INSTANCE_ID"))


def _is_local_runtime() -> bool:
    return not _is_azure_runtime()


def _local_models_dir() -> Path:
    # Default local models dir for SLA regressor artifacts.
    base = Path(str(cfg_get("paths.local_sla_regressor_data_dir", "sla_regressor/local-data")))
    if not base.is_absolute():
        base = Path(__file__).resolve().parents[1] / base
    return base / "models"


def _env_first(*keys: str) -> Optional[str]:
    for k in keys:
        v = os.getenv(k)
        if v is not None and str(v).strip() != "":
            return v
    return None


def handle_sla_regressor_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    """
    Train the SLA resolution-time regressor model.

    This handler is migrated from the previously-standalone `regressor/function_app.py`.
    """
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    cfg = load_config()
    cfg_blob = cfg.get("blob") if isinstance(cfg, dict) else None
    if not isinstance(cfg_blob, dict):
        cfg_blob = {}

    # Local-only path (avoid needing blob access during local dev).
    local_path = body.get("localPath")
    output_local_dir = body.get("outputLocalDir")
    if local_path:
        if _is_azure_runtime():
            return _json_response(
                {"error": "localPath is only supported when running locally (not in Azure)."},
                status_code=400,
            )

        src_path = Path(str(local_path))
        if not src_path.exists():
            return _json_response({"error": f"localPath does not exist: {src_path}"}, status_code=400)

        try:
            cfg = load_config()
            cleaned_df, proc_stats = process_raw_file(src_path, cfg)
            train_artifacts = train_from_cleaned(cleaned_df, cfg)

            out_dir = (
                Path(str(output_local_dir))
                if output_local_dir
                else Path(tempfile.mkdtemp(prefix="cosmic_lgbm_local_"))
            )
            out_dir.mkdir(parents=True, exist_ok=True)
            files = write_artifacts(out_dir, train_artifacts)

            return _json_response(
                {
                    "status": "ok",
                    "mode": "local",
                    "input": {"localPath": str(src_path)},
                    "output": {"localDir": str(out_dir), "files": {k: str(v) for k, v in files.items()}},
                    "process": proc_stats.__dict__,
                    "metrics": train_artifacts.metrics,
                }
            )
        except Exception as exc:
            logging.exception("Local regressor training failed")
            return _json_response({"status": "error", "message": str(exc)}, status_code=500)

    storage_account = body.get("storageAccount") or _env_first("STORAGE_ACCOUNT_NAME") or "stslalightgbmuateu"
    container = (
        body.get("container")
        or _env_first("SLA_REGRESSOR_TRAINING_CONTAINER", "REGRESSOR_TRAINING_CONTAINER", "TRAINING_CONTAINER")
        or "train-data"
    )
    # Default blob is convenience; override via body.blob or env vars.
    blob = (
        body.get("blob")
        or _env_first("SLA_REGRESSOR_TRAINING_BLOB", "REGRESSOR_TRAINING_BLOB", "TRAINING_BLOB")
        or ""
    )

    output_container = (
        body.get("outputContainer")
        or _env_first("SLA_REGRESSOR_OUTPUT_CONTAINER", "REGRESSOR_OUTPUT_CONTAINER", "OUTPUT_CONTAINER")
        or container
    )
    output_prefix = (
        body.get("outputPrefix")
        or _env_first("SLA_REGRESSOR_OUTPUT_PREFIX", "REGRESSOR_OUTPUT_PREFIX", "OUTPUT_PREFIX")
        or cfg_blob.get("model_prefix")
        or "models/"
    )

    if not container:
        return _json_response(
            {"error": "Missing training container. Set TRAINING_CONTAINER or pass body.container"},
            status_code=400,
        )
    if not blob:
        return _json_response(
            {
                "error": (
                    "Missing training blob. Set TRAINING_BLOB (shared single source) or pass body.blob. "
                    "Tip: keep all models pointed at the same TRAINING_BLOB, and let each model's process_data "
                    "derive its own targets/features."
                )
            },
            status_code=400,
        )
    if not output_container:
        return _json_response(
            {"error": "Missing output container. Set OUTPUT_CONTAINER or pass body.outputContainer"},
            status_code=400,
        )

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    raw_local = Path(tempfile.gettempdir()) / f"raw_{ts}_{Path(blob).name}"

    try:
        logging.info("Downloading regressor training data from blob: %s/%s", container, blob)
        download_blob_to_file(storage_account, container, blob, raw_local)

        cfg = load_config()
        cleaned_df, proc_stats = process_raw_file(raw_local, cfg)
        train_artifacts = train_from_cleaned(cleaned_df, cfg)

        out_dir = Path(tempfile.mkdtemp(prefix="cosmic_lgbm_"))
        files = write_artifacts(out_dir, train_artifacts)

        prefix = str(output_prefix).rstrip("/")
        model_blob = f"{prefix}/model_{ts}.pkl"
        peaks_blob = f"{prefix}/peaks_{ts}.pkl"
        enc_blob = f"{prefix}/encodings_{ts}.pkl"
        metrics_blob = f"{prefix}/metrics_{ts}.json"

        logging.info("Uploading regressor artifacts to blob container: %s", output_container)
        upload_file_to_blob(storage_account, output_container, model_blob, files["model"])
        upload_file_to_blob(storage_account, output_container, peaks_blob, files["peaks"])
        upload_file_to_blob(storage_account, output_container, enc_blob, files["encodings"])
        upload_file_to_blob(storage_account, output_container, metrics_blob, files["metrics"])

        return _json_response(
            {
                "status": "ok",
                "storageAccount": storage_account,
                "input": {"container": container, "blob": blob},
                "output": {
                    "container": output_container,
                    "modelBlob": model_blob,
                    "peaksBlob": peaks_blob,
                    "encodingsBlob": enc_blob,
                    "metricsBlob": metrics_blob,
                },
                "process": proc_stats.__dict__,
                "metrics": train_artifacts.metrics,
            }
        )
    except Exception as exc:
        logging.exception("Regressor training failed")
        return _json_response({"status": "error", "message": str(exc)}, status_code=500)


def handle_sla_regressor_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    """
    Infer SLA resolution-time predictions for a batch of records or a blob input table.
    """
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    cfg = load_config()
    cfg_blob = cfg.get("blob") if isinstance(cfg, dict) else None
    if not isinstance(cfg_blob, dict):
        cfg_blob = {}

    storage_account = body.get("storageAccount") or _env_first("STORAGE_ACCOUNT_NAME") or "stslalightgbmuateu"

    records = body.get("records")
    use_local_artifacts = bool(body.get("useLocalArtifacts")) and _is_local_runtime()
    model_local_dir = body.get("modelLocalDir")

    if use_local_artifacts:
        # Local mode: load artifacts from disk, do not touch blob storage.
        try:
            models_dir = Path(str(model_local_dir)) if model_local_dir else _local_models_dir()
            if not models_dir.is_absolute():
                models_dir = Path(__file__).resolve().parents[1] / models_dir

            model_path = models_dir / "model.pkl"
            peaks_path = models_dir / "peaks.pkl"
            enc_path = models_dir / "encodings.pkl"
            missing = [str(p) for p in (model_path, peaks_path, enc_path) if not p.exists()]
            if missing:
                return _json_response(
                    {
                        "status": "error",
                        "message": (
                            "Missing local SLA regressor artifacts. Train locally first, "
                            "then point infer at the same output directory."
                        ),
                        "missing": missing,
                        "hint": "Run /api/sla-regressor-lightgbm-train with outputLocalDir set to this folder.",
                    },
                    status_code=400,
                )

            if not isinstance(records, list) or not records:
                return _json_response(
                    {"error": "Missing input. Provide body.records (inline) when useLocalArtifacts=true."},
                    status_code=400,
                )

            artifacts = artifacts_from_files(
                model_path=str(model_path),
                peaks_path=str(peaks_path),
                encodings_path=str(enc_path),
            )
            df_in = pd.DataFrame(records)
            out_df, _full_df = predict_df(df_in, artifacts)
            return _json_response(
                {
                    "status": "ok",
                    "mode": "local",
                    "input": {"records": len(records)},
                    "model": {"localDir": str(models_dir)},
                    "predictions": out_df.to_dict(orient="records"),
                }
            )
        except Exception as exc:
            logging.exception("Local SLA regressor inference failed")
            return _json_response({"status": "error", "message": str(exc)}, status_code=500)

    container = (
        body.get("container")
        or _env_first(
            "SLA_REGRESSOR_INFER_CONTAINER",
            "REGRESSOR_INFER_CONTAINER",
            "INFER_CONTAINER",
            "TRAINING_CONTAINER",
        )
        or "train-data"
    )
    blob = body.get("blob") or _env_first("SLA_REGRESSOR_INFER_BLOB", "REGRESSOR_INFER_BLOB", "INFER_BLOB")

    model_container = (
        body.get("modelContainer")
        or _env_first("SLA_REGRESSOR_MODEL_CONTAINER", "REGRESSOR_MODEL_CONTAINER", "MODEL_CONTAINER")
        or container
    )
    model_prefix = (
        body.get("modelPrefix")
        or _env_first("SLA_REGRESSOR_MODEL_PREFIX", "REGRESSOR_MODEL_PREFIX", "MODEL_PREFIX")
        or cfg_blob.get("model_prefix")
        or "models/"
    ).rstrip("/") + "/"

    model_blob = body.get("modelBlob")
    peaks_blob = body.get("peaksBlob")
    enc_blob = body.get("encodingsBlob")

    output_container = (
        body.get("outputContainer")
        or _env_first("SLA_REGRESSOR_OUTPUT_CONTAINER", "REGRESSOR_OUTPUT_CONTAINER", "OUTPUT_CONTAINER")
        or container
    )
    output_prefix = (
        body.get("outputPrefix")
        or _env_first("SLA_REGRESSOR_OUTPUT_PREFIX_PRED", "REGRESSOR_OUTPUT_PREFIX_PRED", "OUTPUT_PREFIX_PRED")
        or cfg_blob.get("inference_output_prefix")
        or "predictions/"
    ).rstrip("/") + "/"

    upload_output = body.get("uploadOutput")
    if upload_output is None:
        upload_output = True

    max_return_rows = body.get("maxReturnRows")
    try:
        max_return_rows_i = int(max_return_rows) if max_return_rows is not None else 100
    except Exception:
        max_return_rows_i = 100

    if records is None and not blob:
        return _json_response(
            {"error": "Missing input. Provide body.records (inline) or body.blob (blob input)."},
            status_code=400,
        )

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    input_local: Optional[Path] = None
    if blob:
        input_local = Path(tempfile.gettempdir()) / f"infer_{ts}_{Path(blob).name}"

    try:
        # Resolve artifacts to use (explicit or latest in prefix)
        if not model_blob:
            model_blob = latest_blob(storage_account, model_container, f"{model_prefix}model_")
        if not peaks_blob:
            peaks_blob = latest_blob(storage_account, model_container, f"{model_prefix}peaks_")
        if not enc_blob:
            enc_blob = latest_blob(storage_account, model_container, f"{model_prefix}encodings_")

        model_local = Path(tempfile.gettempdir()) / f"model_{ts}.pkl"
        peaks_local = Path(tempfile.gettempdir()) / f"peaks_{ts}.pkl"
        enc_local = Path(tempfile.gettempdir()) / f"enc_{ts}.pkl"

        df_in: pd.DataFrame
        if records is not None:
            if not isinstance(records, list):
                return _json_response(
                    {"error": "body.records must be a list of objects (rows)."},
                    status_code=400,
                )
            df_in = pd.DataFrame(records)
        else:
            logging.info("Downloading regressor inference input blob: %s/%s", container, blob)
            if input_local is None:
                raise ValueError("Internal error: input_local is None while blob input was provided.")
            download_blob_to_file(storage_account, container, str(blob), input_local)
            df_in = infer_load_table(str(input_local))

        logging.info("Downloading regressor model artifacts: %s | %s | %s", model_blob, peaks_blob, enc_blob)
        download_blob_to_file(storage_account, model_container, str(model_blob), model_local)
        download_blob_to_file(storage_account, model_container, str(peaks_blob), peaks_local)
        download_blob_to_file(storage_account, model_container, str(enc_blob), enc_local)

        model = joblib.load(model_local)
        peaks = joblib.load(peaks_local)
        encodings = joblib.load(enc_local)
        artifacts = artifacts_from_objects(model, peaks, encodings, cfg=cfg)

        out_df, _full = predict_df(df_in, artifacts)

        out_blob: Optional[str] = None
        if upload_output:
            out_local = Path(tempfile.gettempdir()) / f"predictions_{ts}.csv"
            out_df.to_csv(out_local, index=False)
            out_blob = f"{output_prefix}predictions_{ts}.csv"
            logging.info("Uploading regressor predictions to blob: %s/%s", output_container, out_blob)
            upload_file_to_blob(storage_account, output_container, out_blob, out_local)

        return _json_response(
            {
                "status": "ok",
                "storageAccount": storage_account,
                "input": {"container": container, "blob": blob, "inlineRecords": (records is not None)},
                "artifacts": {
                    "container": model_container,
                    "modelBlob": model_blob,
                    "peaksBlob": peaks_blob,
                    "encodingsBlob": enc_blob,
                },
                "output": {"container": output_container, "blob": out_blob, "rows": int(len(out_df))},
                "preview": out_df.head(max_return_rows_i).to_dict(orient="records"),
            }
        )
    except Exception as exc:
        logging.exception("Regressor inference failed")
        return _json_response({"status": "error", "message": str(exc)}, status_code=500)


# Backwards-compatible aliases (older route names/handlers).
handle_light_gbm_train = handle_sla_regressor_lightgbm_train
handle_light_gbm_infer = handle_sla_regressor_lightgbm_infer


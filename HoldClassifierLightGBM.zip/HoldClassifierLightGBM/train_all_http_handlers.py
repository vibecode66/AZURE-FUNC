import datetime
import json
import logging
import os
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

import azure.functions as func

from blob_io import download_blob_to_file, upload_file_to_blob
from classifier.classifier_process_data import read_training_table
from classifier.classifier_train import train_and_save as train_hold_classifier_and_save
from hold_regressor.hold_regressor_train import train_and_save as train_hold_regressor_and_save
from project_config import cfg_get
from sla_regressor.sla_regressor_process_data import load_config as load_sla_cfg, process_raw_file
from sla_regressor.sla_regressor_train import train_from_cleaned, write_artifacts as write_sla_artifacts


DEFAULT_STORAGE_ACCOUNT = str(cfg_get("storage.account_name", "stslalightgbmuateu"))
DEFAULT_CONTAINER = str(cfg_get("storage.default_container", "train-data"))


def _is_azure_runtime() -> bool:
    return bool(os.getenv("WEBSITE_INSTANCE_ID"))


def _is_local_runtime() -> bool:
    return not _is_azure_runtime()


def _resolve_local_dir(rel: str) -> Path:
    p = Path(rel)
    if p.is_absolute():
        return p
    return Path(__file__).resolve().parent / p


def _json_response(obj: dict[str, Any], status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(json.dumps(obj), status_code=status_code, mimetype="application/json")


def _env_first(*keys: str) -> str | None:
    for k in keys:
        v = os.getenv(k)
        if v is not None and str(v).strip() != "":
            return v
    return None


def handle_case_sla_lightgbm_train_all(req: func.HttpRequest) -> func.HttpResponse:
    """
    Train ALL models (hold classifier, hold regressor, SLA regressor) from the SAME training blob.

    Defaults:
      - container/blob from TRAINING_CONTAINER/TRAINING_BLOB
      - artifacts written back to the same container under model-specific prefixes

    Body options:
      - storageAccount, container, blob
      - holdMinutesCol (classifier + hold regressor)
      - parallel (bool, default true): run trainings concurrently
    """
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    local_path = body.get("localPath")
    if local_path:
        if not _is_local_runtime():
            return _json_response(
                {"status": "error", "message": "localPath is only supported when running locally (not in Azure)."},
                status_code=400,
            )
        src_path = Path(str(local_path))
        if not src_path.is_absolute():
            src_path = Path(__file__).resolve().parent / src_path
        if not src_path.exists():
            return _json_response({"status": "error", "message": f"localPath does not exist: {src_path}"}, status_code=400)

        mode = "local"
        storage_account = None
        container = None
        blob = None
    else:
        mode = "cloud"
        storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME") or DEFAULT_STORAGE_ACCOUNT
        container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
        blob = body.get("blob") or os.getenv("TRAINING_BLOB")
        if not blob:
            return _json_response(
                {"status": "error", "message": "Missing TRAINING_BLOB (shared single source) or body.blob."},
                status_code=400,
            )

    hold_minutes_col = (
        body.get("holdMinutesCol")
        or os.getenv("HOLD_MINUTES_COL")
        or str(cfg_get("training.hold_minutes_col", "HoldTimeInMinutes"))
    )

    parallel = body.get("parallel")
    if parallel is None:
        parallel = True
    parallel = bool(parallel)

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    def _train_hold_classifier() -> dict[str, Any]:
        df = read_training_table(src_path) if local_path else None
        if df is None:
            raw_local = Path(tempfile.gettempdir()) / f"hold_classifier_train_{ts}_{Path(blob).name}"
            download_blob_to_file(str(storage_account), str(container), str(blob), raw_local)
            df = read_training_table(raw_local)

        out_dir = _resolve_local_dir("classifier/local-data/models") if local_path else Path(tempfile.mkdtemp(prefix="hold_classifier_all_"))
        out_dir.mkdir(parents=True, exist_ok=True)
        model_local = out_dir / f"hold_classifier_model_{ts}.txt"
        meta_local = out_dir / f"hold_classifier_meta_{ts}.json"
        _booster, _features, metrics = train_hold_classifier_and_save(
            df,
            dst_model_path=str(model_local),
            dst_meta_path=str(meta_local),
            hold_minutes_col=hold_minutes_col,
            trained_utc=ts,
        )
        if local_path:
            return {
                "status": "ok",
                "mode": "local",
                "metrics": metrics,
                "output": {"localDir": str(out_dir), "model": str(model_local), "meta": str(meta_local)},
            }

        prefix = str(cfg_get("training.model_prefix", "hold-classifier/models/")).rstrip("/") + "/"
        model_blob = f"{prefix}hold_classifier_model_{ts}.txt"
        meta_blob = f"{prefix}hold_classifier_meta_{ts}.json"
        upload_file_to_blob(str(storage_account), str(container), model_blob, model_local)
        upload_file_to_blob(str(storage_account), str(container), meta_blob, meta_local)
        return {"status": "ok", "metrics": metrics, "output": {"container": container, "modelBlob": model_blob, "metaBlob": meta_blob}}

    def _train_hold_regressor() -> dict[str, Any]:
        df = read_training_table(src_path) if local_path else None
        if df is None:
            raw_local = Path(tempfile.gettempdir()) / f"hold_regressor_train_{ts}_{Path(blob).name}"
            download_blob_to_file(str(storage_account), str(container), str(blob), raw_local)
            df = read_training_table(raw_local)

        out_dir = _resolve_local_dir("hold_regressor/local-data/models") if local_path else Path(tempfile.mkdtemp(prefix="hold_regressor_all_"))
        out_dir.mkdir(parents=True, exist_ok=True)
        model_local = out_dir / f"hold_regressor_model_{ts}.pkl"
        meta_local = out_dir / f"hold_regressor_meta_{ts}.json"
        _model, _features, metrics = train_hold_regressor_and_save(
            df,
            dst_model_path=str(model_local),
            dst_meta_path=str(meta_local),
            hold_minutes_col=hold_minutes_col,
            trained_utc=ts,
        )
        if local_path:
            return {
                "status": "ok",
                "mode": "local",
                "metrics": metrics,
                "output": {"localDir": str(out_dir), "model": str(model_local), "meta": str(meta_local)},
            }

        prefix = str(cfg_get("hold_regressor.blob.model_prefix", "hold-regressor-lightgbm/models/")).rstrip("/") + "/"
        model_blob = f"{prefix}hold_regressor_model_{ts}.pkl"
        meta_blob = f"{prefix}hold_regressor_meta_{ts}.json"
        upload_file_to_blob(str(storage_account), str(container), model_blob, model_local)
        upload_file_to_blob(str(storage_account), str(container), meta_blob, meta_local)
        return {"status": "ok", "metrics": metrics, "output": {"container": container, "modelBlob": model_blob, "metaBlob": meta_blob}}

    def _train_sla_regressor() -> dict[str, Any]:
        raw_path = src_path if local_path else None
        if raw_path is None:
            raw_local = Path(tempfile.gettempdir()) / f"sla_regressor_train_{ts}_{Path(blob).name}"
            download_blob_to_file(str(storage_account), str(container), str(blob), raw_local)
            raw_path = raw_local

        cfg = load_sla_cfg()
        cleaned_df, proc_stats = process_raw_file(Path(raw_path), cfg)
        artifacts = train_from_cleaned(cleaned_df, cfg)
        out_dir = _resolve_local_dir("sla_regressor/local-data/models") if local_path else Path(tempfile.mkdtemp(prefix="sla_regressor_all_"))
        files = write_sla_artifacts(out_dir, artifacts)
        if local_path:
            return {
                "status": "ok",
                "mode": "local",
                "process": proc_stats.__dict__,
                "metrics": artifacts.metrics,
                "output": {"localDir": str(out_dir), "files": {k: str(v) for k, v in files.items()}},
            }

        prefix = str(cfg_get("sla_regressor.blob.model_prefix", "sla-regressor-lightgbm/models/")).rstrip("/")
        model_blob = f"{prefix}/model_{ts}.pkl"
        peaks_blob = f"{prefix}/peaks_{ts}.pkl"
        enc_blob = f"{prefix}/encodings_{ts}.pkl"
        metrics_blob = f"{prefix}/metrics_{ts}.json"
        upload_file_to_blob(str(storage_account), str(container), model_blob, files["model"])
        upload_file_to_blob(str(storage_account), str(container), peaks_blob, files["peaks"])
        upload_file_to_blob(str(storage_account), str(container), enc_blob, files["encodings"])
        upload_file_to_blob(str(storage_account), str(container), metrics_blob, files["metrics"])
        return {"status": "ok", "process": proc_stats.__dict__, "metrics": artifacts.metrics, "output": {"container": container, "modelBlob": model_blob, "peaksBlob": peaks_blob, "encodingsBlob": enc_blob, "metricsBlob": metrics_blob}}

    jobs: dict[str, Callable[[], dict[str, Any]]] = {
        "hold_classifier": _train_hold_classifier,
        "hold_regressor": _train_hold_regressor,
        "sla_regressor": _train_sla_regressor,
    }

    results: dict[str, Any] = {}
    if parallel:
        # Note: this will increase CPU/memory usage; set parallel=false if needed.
        with ThreadPoolExecutor(max_workers=3) as ex:
            fut_to_name = {ex.submit(fn): name for name, fn in jobs.items()}
            for fut in as_completed(fut_to_name):
                name = fut_to_name[fut]
                try:
                    results[name] = fut.result()
                except Exception as exc:
                    logging.exception("Train-all: %s failed", name)
                    results[name] = {"status": "error", "message": str(exc)}
    else:
        for name, fn in jobs.items():
            try:
                results[name] = fn()
            except Exception as exc:
                logging.exception("Train-all: %s failed", name)
                results[name] = {"status": "error", "message": str(exc)}

    return _json_response(
        {
            "status": "ok",
            "mode": mode,
            "input": {"localPath": str(src_path)} if local_path else {"storageAccount": storage_account, "container": container, "blob": blob},
            "trainedUtc": ts,
            "parallel": parallel,
            "results": results,
        }
    )


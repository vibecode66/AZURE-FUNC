from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import lightgbm as lgb
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split

from classifier.classifier_process_data import prepare_training_data
from project_config import cfg_get


RANDOM_STATE = int(cfg_get("model.random_state", 42))


def train_hold_classifier(
    df: pd.DataFrame,
    *,
    hold_minutes_col: str = "HoldTimeInMinutes",
    random_state: int = RANDOM_STATE,
) -> Tuple[lgb.Booster, list[str], Dict[str, Any]]:
    """
    Train a LightGBM binary classifier and return:
      - booster: LightGBM Booster (savable via booster.save_model)
      - features: list of feature column names used
      - metrics: dict with AUC/AP and class balance
    """
    X, y, features, df_labeled = prepare_training_data(df, hold_minutes_col=hold_minutes_col)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state, stratify=y
    )

    clf = lgb.LGBMClassifier(objective="binary", metric="auc", random_state=random_state)
    clf.fit(X_train, y_train)

    y_pred_prob = clf.predict_proba(X_test)[:, 1]
    auc = float(roc_auc_score(y_test, y_pred_prob))
    ap = float(average_precision_score(y_test, y_pred_prob))

    metrics: Dict[str, Any] = {
        "roc_auc": auc,
        "average_precision": ap,
        "positives": int(y.sum()),
        "negatives": int((1 - y).sum()),
        "positive_rate": float(y.mean()),
        "n_rows": int(len(df_labeled)),
        "n_features": int(len(features)),
    }

    return clf.booster_, features, metrics


def save_model_artifacts(
    booster: lgb.Booster,
    features: list[str],
    *,
    dst_model_path: str,
    dst_meta_path: str,
    extra_meta: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Save a LightGBM-native model file + JSON metadata to local disk.
    - model: `Booster.save_model(...)` (text format)
    - meta: includes `features` + optional extras
    """
    model_path = Path(dst_model_path)
    meta_path = Path(dst_meta_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.parent.mkdir(parents=True, exist_ok=True)

    booster.save_model(str(model_path))

    meta: Dict[str, Any] = {"features": features}
    if extra_meta:
        meta.update(extra_meta)

    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def train_and_save(
    df: pd.DataFrame,
    *,
    hold_minutes_col: str,
    dst_model_path: str,
    dst_meta_path: str,
    trained_utc: str,
) -> Tuple[lgb.Booster, list[str], Dict[str, Any]]:
    """
    Train a hold classifier and persist artifacts (model + metadata).
    """
    booster, features, metrics = train_hold_classifier(df, hold_minutes_col=hold_minutes_col)
    save_model_artifacts(
        booster,
        features,
        dst_model_path=dst_model_path,
        dst_meta_path=dst_meta_path,
        extra_meta={
            "holdMinutesCol": hold_minutes_col,
            "trainedUtc": trained_utc,
            "metrics": metrics,
        },
    )
    return booster, features, metrics


from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd
from zipfile import BadZipFile

from project_config import cfg_get


PREFERRED_FEATURES: list[str] = list(cfg_get("features.preferred", []) or [])


def read_csv_safe(path: str, usecols: Optional[list[str]] = None) -> pd.DataFrame:
    """
    Read CSV with a fallback chunked path for very large files.
    """
    try:
        if usecols:
            return pd.read_csv(path, usecols=usecols)
        return pd.read_csv(path)
    except Exception as exc:
        # Fallback to chunked reading if a single-pass read fails (e.g., memory/parse issues)
        print(f"Primary read failed ({exc}); falling back to chunked read (100k rows/chunk).")
        chunks: list[pd.DataFrame] = []
        for chunk in pd.read_csv(path, usecols=usecols, chunksize=100000):
            chunks.append(chunk)
        return pd.concat(chunks, ignore_index=True)


def read_training_table(path: Path) -> pd.DataFrame:
    """
    Load training data from CSV or Excel (xls/xlsx).
    """
    suffix = path.suffix.lower()
    if suffix == ".xlsx":
        try:
            return pd.read_excel(path, engine="openpyxl")
        except BadZipFile:
            # Common case: file is actually .xls (or not a real xlsx) but named .xlsx.
            try:
                return pd.read_excel(path, engine="xlrd")
            except Exception as exc:
                raise ValueError(
                    "Input looks like it is not a valid .xlsx file (openpyxl: 'File is not a zip file'). "
                    "If this is an old Excel file, use a real .xls extension or convert to .xlsx."
                ) from exc
    if suffix == ".xls":
        try:
            return pd.read_excel(path, engine="xlrd")
        except ImportError as exc:
            raise ValueError(
                "Reading .xls requires 'xlrd>=2.0.1'. Convert the file to .xlsx or install xlrd."
            ) from exc
        except BadZipFile as exc:
            # In rare cases a mislabeled xlsx might come through with .xls extension.
            raise ValueError(
                "Input looks like it is not a valid .xls file. If this file is actually .xlsx, "
                "rename it to .xlsx and retry."
            ) from exc
    return read_csv_safe(str(path))


def _coerce_minutes(series: pd.Series) -> pd.Series:
    # Handles numbers, "NULL", empty strings, etc.
    return pd.to_numeric(series, errors="coerce")


def pick_features(df: pd.DataFrame) -> list[str]:
    """
    Keep only preferred feature columns that are present in the dataset.
    """
    return [c for c in PREFERRED_FEATURES if c in df.columns]


def prepare_hold_labels(df: pd.DataFrame, *, hold_minutes_col: str) -> pd.DataFrame:
    df = df.copy()
    df[hold_minutes_col] = _coerce_minutes(df[hold_minutes_col])
    df["target_hold_minutes"] = df[hold_minutes_col].fillna(0)
    df["is_hold_case"] = (df["target_hold_minutes"] > 0).astype(int)
    return df


def prepare_training_data(
    df: pd.DataFrame,
    *,
    hold_minutes_col: str,
) -> tuple[pd.DataFrame, pd.Series, list[str], pd.DataFrame]:
    """
    Returns:
      - X (feature frame)
      - y (label series)
      - features (list[str])
      - df_labeled (df with is_hold_case/target_hold_minutes)
    """
    if hold_minutes_col not in df.columns:
        raise ValueError(f"Missing required column: {hold_minutes_col}")

    df_labeled = prepare_hold_labels(df, hold_minutes_col=hold_minutes_col)
    features = pick_features(df_labeled)
    if not features:
        raise ValueError("No usable feature columns found in the dataset.")

    for col in features:
        df_labeled[col] = df_labeled[col].fillna("Unknown").astype("category")

    X = df_labeled[features]
    y = df_labeled["is_hold_case"]
    return X, y, features, df_labeled


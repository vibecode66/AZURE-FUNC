from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Tuple

import lightgbm as lgb
import numpy as np
import pandas as pd


def load_model_artifacts(
    model_path: str, meta_path: str
) -> Tuple[lgb.Booster, list[str], Dict[str, Any]]:
    booster = lgb.Booster(model_file=str(model_path))
    meta = json.loads(Path(meta_path).read_text(encoding="utf-8"))
    features = list(meta.get("features") or [])
    if not features:
        raise ValueError("Model metadata missing 'features'.")
    return booster, features, meta


def predict_hold_probability(
    booster: lgb.Booster,
    features: list[str],
    payload: Dict[str, Any],
) -> float:
    row = {f: payload.get(f, "Unknown") for f in features}
    X = pd.DataFrame([row])
    for col in features:
        X[col] = X[col].fillna("Unknown").astype("category")
    prob = float(booster.predict(X[features])[0])
    return float(np.clip(prob, 0.0, 1.0))


def infer_from_loaded(
    booster: lgb.Booster,
    features: list[str],
    *,
    record: Dict[str, Any],
    threshold: float,
) -> Tuple[float, int]:
    prob = predict_hold_probability(booster, features, record)
    pred = int(prob >= threshold)
    return prob, pred


def infer_from_artifacts(
    *,
    record: Dict[str, Any],
    model_path: str,
    meta_path: str,
    threshold: float,
) -> Tuple[float, int]:
    booster, features, _meta = load_model_artifacts(model_path, meta_path)
    return infer_from_loaded(booster, features, record=record, threshold=threshold)


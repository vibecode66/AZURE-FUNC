import datetime
import json
import logging
import os
import tempfile
import base64
from pathlib import Path

import azure.functions as func

from project_config import cfg_get
from blob_io import download_blob_to_file, latest_blob, upload_file_to_blob
from classifier.classifier_process_data import read_training_table
from classifier.classifier_train import train_and_save
from classifier.classifier_infer import infer_from_artifacts

DEFAULT_STORAGE_ACCOUNT = str(cfg_get("storage.account_name", "stslalightgbmuateu"))
DEFAULT_CONTAINER = str(cfg_get("storage.default_container", "train-data"))
DEFAULT_MODEL_PREFIX = str(cfg_get("training.model_prefix", "hold-classifier-model/"))
DEFAULT_TRAINING_DATA_PREFIX = str(
    cfg_get("training.training_data_prefix", "hold-classifier-training-data/")
)


def _is_local_runtime() -> bool:
    return not bool(os.getenv("WEBSITE_INSTANCE_ID"))


def _local_data_dir() -> Path:
    cfg_path = str(cfg_get("paths.local_data_dir", "classifier/local-data"))
    p = Path(cfg_path)
    if p.is_absolute():
        return p
    # Resolve relative to app root so path behaves consistently across modules.
    return Path(__file__).resolve().parents[1] / p


def _latest_local_artifact(prefix: str, suffix: str) -> Path | None:
    models_dir = _local_data_dir() / "models"
    if not models_dir.exists():
        return None
    # Pick most recently modified artifact to align infer with latest local train.
    matches = sorted(models_dir.glob(f"{prefix}*{suffix}"), key=lambda p: p.stat().st_mtime)
    return matches[-1] if matches else None


def _json_response(obj, status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(obj),
        status_code=status_code,
        mimetype="application/json",
    )

def _extract_uploaded_file(req: func.HttpRequest, body: dict):
    # Preferred path for multipart/form-data uploads (curl -F "file=@...").
    if hasattr(req, "files") and req.files:
        uploaded = req.files.get("file")
        if uploaded:
            return uploaded.filename, uploaded.read()

    # Optional JSON fallback: {"fileName":"x.xlsx","fileBase64":"..."}.
    file_name = body.get("fileName")
    file_b64 = body.get("fileBase64")
    if file_name and file_b64:
        return file_name, base64.b64decode(file_b64)

    return None, None


def handle_hold_classifier_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Expect JSON payload for all train requests.
        body = req.get_json()
    except ValueError:
        # Treat missing/invalid JSON as empty body and rely on defaults.
        body = {}

    # Label column can be overridden per-request or via env.
    hold_minutes_col = (
        body.get("holdMinutesCol")
        or os.getenv("HOLD_MINUTES_COL")
        or str(cfg_get("training.hold_minutes_col", "HoldTimeInMinutes"))
    )

    upload_name, upload_bytes = _extract_uploaded_file(req, body)
    if upload_name and upload_bytes:
        # Upload incoming file to training-data prefix in blob, then train from that blob.
        storage_account = (
            body.get("storageAccount")
            or os.getenv("STORAGE_ACCOUNT_NAME")
            or DEFAULT_STORAGE_ACCOUNT
        )
        container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
        training_prefix = (
            body.get("trainingDataPrefix")
            or os.getenv("TRAINING_DATA_PREFIX")
            or DEFAULT_TRAINING_DATA_PREFIX
        ).rstrip("/") + "/"
        ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        safe_name = Path(upload_name).name
        uploaded_local = Path(tempfile.gettempdir()) / f"uploaded_train_{ts}_{safe_name}"
        uploaded_local.parent.mkdir(parents=True, exist_ok=True)
        with open(uploaded_local, "wb") as f:
            f.write(upload_bytes)

        uploaded_blob = f"{training_prefix}{ts}_{safe_name}"
        upload_file_to_blob(storage_account, container, uploaded_blob, uploaded_local)
        body["storageAccount"] = storage_account
        body["container"] = container
        body["blob"] = uploaded_blob

    # Local-only training mode: default to local-data CSV when running locally.
    local_path = body.get("localPath")
    if _is_local_runtime() and not local_path and not upload_name:
        default_local_csv = Path(
            str(
                cfg_get(
                    "paths.default_local_training_csv",
                    str(_local_data_dir() / "Cases_CompleteSet_ActualTime.csv"),
                )
            )
        )
        if not default_local_csv.is_absolute():
            default_local_csv = Path(__file__).resolve().parents[1] / default_local_csv
        if default_local_csv.exists():
            local_path = str(default_local_csv)
    if local_path:
        if not _is_local_runtime():
            return _json_response(
                {"error": "localPath is only supported when running locally (not in Azure)."},
                status_code=400,
            )
        # Validate local training input path early for fast feedback.
        src_path = Path(str(local_path))
        if not src_path.exists():
            return _json_response(
                {"error": f"localPath does not exist: {src_path}"},
                status_code=400,
            )

        try:
            # Train directly from local CSV and persist artifacts under local-data/models.
            df = read_training_table(src_path)

            # Store model in local-data/models/ (ignored by git/func)
            out_dir = _local_data_dir() / "models"
            out_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            model_path = out_dir / f"hold_classifier_model_{ts}.txt"
            meta_path = out_dir / f"hold_classifier_meta_{ts}.json"
            _booster, _features, metrics = train_and_save(
                df,
                dst_model_path=str(model_path),
                dst_meta_path=str(meta_path),
                hold_minutes_col=hold_minutes_col,
                trained_utc=ts,
            )

            return _json_response(
                {
                    "status": "ok",
                    "mode": "local",
                    "input": {"localPath": str(src_path)},
                    "output": {
                        "localDir": str(out_dir),
                        "model": str(model_path),
                        "meta": str(meta_path),
                    },
                    "metrics": metrics,
                }
            )
        except Exception as e:
            logging.exception("Local training failed")
            return _json_response({"status": "error", "message": str(e)}, status_code=500)

    storage_account = (
        body.get("storageAccount")
        or os.getenv("STORAGE_ACCOUNT_NAME")
        or DEFAULT_STORAGE_ACCOUNT
    )

    # Blob training input location can come from request or environment defaults.
    container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
    blob = body.get("blob") or os.getenv("TRAINING_BLOB")
    if not container or not blob:
        return _json_response(
            {
                "error": (
                    "Missing training input. Set TRAINING_CONTAINER/TRAINING_BLOB "
                    "or pass body.container/body.blob"
                )
            },
            status_code=400,
        )

    model_container = body.get("modelContainer") or os.getenv("MODEL_CONTAINER") or container
    # Normalize prefix so generated blob paths are predictable.
    model_prefix = (
        (body.get("modelPrefix") or os.getenv("MODEL_PREFIX") or DEFAULT_MODEL_PREFIX).rstrip("/")
        + "/"
    )

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    if _is_local_runtime():
        # Keep temp/download artifacts under local-data for easier local cleanup.
        tmp_dir = _local_data_dir() / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        train_local = tmp_dir / f"hold_train_{ts}_{Path(blob).name}"
        out_dir = tmp_dir
    else:
        train_local = Path(tempfile.gettempdir()) / f"hold_train_{ts}_{Path(blob).name}"
        out_dir = Path(tempfile.mkdtemp(prefix="hold_classifier_artifacts_"))
    model_local = out_dir / f"hold_classifier_model_{ts}.txt"
    meta_local = out_dir / f"hold_classifier_meta_{ts}.json"

    try:
        # Download training data locally, train, then publish artifacts to Blob Storage.
        logging.info("Downloading training data from blob: %s/%s", container, blob)
        download_blob_to_file(storage_account, container, blob, train_local)

        df = read_training_table(train_local)
        _booster, _features, metrics = train_and_save(
            df,
            dst_model_path=str(model_local),
            dst_meta_path=str(meta_local),
            hold_minutes_col=hold_minutes_col,
            trained_utc=ts,
        )

        model_blob = f"{model_prefix}hold_classifier_model_{ts}.txt"
        meta_blob = f"{model_prefix}hold_classifier_meta_{ts}.json"

        logging.info("Uploading model artifacts to blob container: %s", model_container)
        upload_file_to_blob(storage_account, model_container, model_blob, model_local)
        upload_file_to_blob(storage_account, model_container, meta_blob, meta_local)

        return _json_response(
            {
                "status": "ok",
                "storageAccount": storage_account,
                "input": {"container": container, "blob": blob},
                "output": {
                    "container": model_container,
                    "modelBlob": model_blob,
                    "metaBlob": meta_blob,
                },
                "metrics": metrics,
            }
        )
    except Exception as e:
        logging.exception("Training failed")
        return _json_response({"status": "error", "message": str(e)}, status_code=500)


def handle_hold_classifier_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Expect JSON payload for infer requests.
        body = req.get_json()
    except ValueError:
        # Allow handler to return validation errors from an empty body.
        body = {}

    # allow either {"record": {...}} or a flat object payload
    record = body.get("record") if isinstance(body, dict) else None
    if record is None:
        record = body
    if not isinstance(record, dict) or not record:
        return _json_response({"error": "Missing input record (JSON object)."}, status_code=400)

    explicit_storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME")
    explicit_model_container = body.get("modelContainer") or os.getenv("MODEL_CONTAINER")
    storage_account = explicit_storage_account or DEFAULT_STORAGE_ACCOUNT
    model_container = explicit_model_container or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
    # In local runtime, auto-fallback to local models when storage settings are absent.
    use_local_artifacts = _is_local_runtime() and (not explicit_storage_account or not explicit_model_container)

    threshold = (
        body.get("threshold")
        or os.getenv("HOLD_CLASSIFIER_THRESHOLD")
        or str(cfg_get("inference.threshold", 0.5))
    )
    try:
        # Threshold is user input; fallback to safe default when malformed.
        threshold_f = float(threshold)
    except Exception:
        threshold_f = 0.5

    if use_local_artifacts:
        # Local mode: score using the latest local model artifacts.
        model_local = _latest_local_artifact("hold_classifier_model_", ".txt")
        meta_local = _latest_local_artifact("hold_classifier_meta_", ".json")
        if not model_local or not meta_local:
            return _json_response(
                {
                    "error": (
                        "No local model artifacts found in classifier/local-data/models. "
                        "Run local training first."
                    )
                },
                status_code=400,
            )
        try:
            prob, pred = infer_from_artifacts(
                record=record,
                model_path=str(model_local),
                meta_path=str(meta_local),
                threshold=threshold_f,
            )
            ticket_number = record.get("TicketNumber")
            resp: dict[str, Any] = {
                "status": "ok",
                "mode": "local",
                "ticketNumber": ticket_number,
                "predicted_hold_probability": round(prob, 6),
                "predicted_is_hold_case": pred,
                "threshold": threshold_f,
                "model": {"localModel": str(model_local), "localMeta": str(meta_local)},
            }

            upload_output = body.get("uploadOutput") is True
            if upload_output:
                # Local runtime without explicit storage settings: store under local-data/outputs.
                out_dir = _local_data_dir() / "outputs"
                out_dir.mkdir(parents=True, exist_ok=True)
                ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
                out_path = out_dir / f"hold_classifier_infer_{ts}.json"
                out_path.write_text(json.dumps({"record": record, "result": resp}, indent=2), encoding="utf-8")
                resp["output"] = {"mode": "local", "localPath": str(out_path)}

            return _json_response(resp)
        except Exception as e:
            logging.exception("Inference failed (local artifacts)")
            return _json_response({"status": "error", "message": str(e)}, status_code=500)

    model_prefix = (
        body.get("modelPrefix")
        or os.getenv("MODEL_PREFIX")
        or DEFAULT_MODEL_PREFIX
    ).rstrip("/") + "/"
    model_blob = body.get("modelBlob")
    meta_blob = body.get("metaBlob")

    # If blob names are omitted, infer chooses the latest artifacts by prefix.
    if not model_blob:
        model_blob = latest_blob(storage_account, model_container, f"{model_prefix}hold_classifier_model_")
    if not meta_blob:
        meta_blob = latest_blob(storage_account, model_container, f"{model_prefix}hold_classifier_meta_")

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    if _is_local_runtime():
        # Keep downloaded model blobs inside local-data in local runs.
        tmp_dir = _local_data_dir() / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        model_local = tmp_dir / f"hold_model_{ts}.txt"
        meta_local = tmp_dir / f"hold_meta_{ts}.json"
    else:
        model_local = Path(tempfile.gettempdir()) / f"hold_model_{ts}.txt"
        meta_local = Path(tempfile.gettempdir()) / f"hold_meta_{ts}.json"

    try:
        # Download selected model artifacts and score the incoming record.
        logging.info("Downloading model artifacts: %s | %s", model_blob, meta_blob)
        download_blob_to_file(storage_account, model_container, model_blob, model_local)
        download_blob_to_file(storage_account, model_container, meta_blob, meta_local)

        prob, pred = infer_from_artifacts(
            record=record,
            model_path=str(model_local),
            meta_path=str(meta_local),
            threshold=threshold_f,
        )

        ticket_number = record.get("TicketNumber")
        resp: dict[str, Any] = {
            "status": "ok",
            "ticketNumber": ticket_number,
            "predicted_hold_probability": round(prob, 6),
            "predicted_is_hold_case": pred,
            "threshold": threshold_f,
            "model": {"container": model_container, "modelBlob": model_blob, "metaBlob": meta_blob},
        }

        upload_output = body.get("uploadOutput") is True
        if upload_output:
            # Upload the single-record inference result to blob for traceability/auditing.
            output_container = (
                body.get("outputContainer")
                or os.getenv("HOLD_INFER_OUTPUT_CONTAINER")
                or model_container
            )
            output_prefix = (
                body.get("outputPrefix")
                or os.getenv("HOLD_INFER_OUTPUT_PREFIX")
                or str(cfg_get("inference.output_prefix", "hold-classifier/inference-outputs/"))
            ).rstrip("/") + "/"

            out_blob = f"{output_prefix}hold_classifier_infer_{ts}.json"
            out_local = Path(tempfile.gettempdir()) / f"hold_classifier_infer_{ts}.json"
            out_local.write_text(json.dumps({"record": record, "result": resp}, indent=2), encoding="utf-8")
            try:
                upload_file_to_blob(storage_account, output_container, out_blob, out_local)
                resp["output"] = {"container": output_container, "blob": out_blob}
            except Exception as exc:
                # Do not fail inference if output upload fails.
                resp["outputUploadError"] = str(exc)

        return _json_response(resp)
    except Exception as e:
        logging.exception("Inference failed")
        return _json_response({"status": "error", "message": str(e)}, status_code=500)

"""
Classifier package for Azure Functions routing.
"""


import os
from pathlib import Path
from typing import Optional

from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

from project_config import cfg_get


DEFAULT_UAMI_CLIENT_ID = str(
    cfg_get("identity.default_uami_client_id", "89ab0e3a-79c6-4737-8946-e6e7bbda01c0")
)


def get_credential() -> DefaultAzureCredential:
    """
    Use Managed Identity in Azure. If you want to force the User Assigned MI, set:
      - AZURE_CLIENT_ID (recommended), or
      - MANAGED_IDENTITY_CLIENT_ID
    """
    client_id = os.getenv("AZURE_CLIENT_ID") or os.getenv("MANAGED_IDENTITY_CLIENT_ID")
    if not client_id and os.getenv("WEBSITE_INSTANCE_ID"):
        client_id = DEFAULT_UAMI_CLIENT_ID
    return DefaultAzureCredential(managed_identity_client_id=client_id)


def blob_service_client(account_name: str) -> BlobServiceClient:
    return BlobServiceClient(
        account_url=f"https://{account_name}.blob.core.windows.net",
        credential=get_credential(),
    )


def download_blob_to_file(account: str, container: str, blob: str, dst_path: Path) -> None:
    bsc = blob_service_client(account)
    bc = bsc.get_blob_client(container=container, blob=blob)
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    with open(dst_path, "wb") as f:
        bc.download_blob().readinto(f)


def upload_file_to_blob(account: str, container: str, blob: str, src_path: Path) -> None:
    bsc = blob_service_client(account)
    bc = bsc.get_blob_client(container=container, blob=blob)
    with open(src_path, "rb") as f:
        bc.upload_blob(f, overwrite=True)


def latest_blob(account: str, container: str, prefix: str) -> str:
    """
    Return the most recently modified blob name under the given prefix.
    Requires list permission (Blob Data Reader/Contributor).
    """
    bsc = blob_service_client(account)
    cc = bsc.get_container_client(container)
    latest_name: Optional[str] = None
    latest_ts = None
    for b in cc.list_blobs(name_starts_with=prefix):
        lm = getattr(b, "last_modified", None)
        if latest_ts is None or (lm is not None and lm > latest_ts):
            latest_ts = lm
            latest_name = b.name
    if not latest_name:
        raise FileNotFoundError(
            f"No blobs found with prefix '{prefix}' in container '{container}'"
        )
    return latest_name


# Case SLA Prediction (Azure Functions)

Python Azure Functions app that exposes two ML services:

- **Hold classifier** (binary classification): predicts whether a case is likely to become a hold case (probability + decision).
- **SLA regressor** (regression): predicts a case resolution datetime based on engineered workload/time features (Tweedie LightGBM).

## Endpoints

When running locally, Functions default to the `/api` prefix.

### Train all (hold classifier + hold regressor + SLA regressor)

- **Train all**: `POST /api/case-sla-lightgbm-train-all`
  - Trains **all three** models from the same input file/blob.
  - Local mode:
    - `{"localPath":"dataset/Cases_CompleteSet_ActualTime-excel.xlsx","parallel":true,"holdMinutesCol":"HoldTimeInMinutes"}`
    - Writes artifacts to:
      - `classifier/local-data/models/`
      - `hold_regressor/local-data/models/`
      - `sla_regressor/local-data/models/`
  - Output formatting:
    - When running locally, the response defaults to **pretty-printed JSON** to avoid terminals wrapping/garbling huge one-line payloads.
    - You can force this with `{"pretty": true}` (or disable with `{"pretty": false}`).

### Hold classifier

- **Train**: `POST /api/hold-classifier-lightGBM-train`
  - Trains the model from CSV and writes artifacts (model + metadata).
  - In local runtime, if `localPath` is omitted, it defaults to:
    `classifier/local-data/Cases_CompleteSet_ActualTime.csv`
  - Local artifacts are written to:
    `classifier/local-data/models/`

- **Infer**: `POST /api/hold-classifier-lightGBM-infer`
  - Scores a single JSON record and returns `predicted_hold_probability` and a binary decision using a threshold.
  - In local runtime, if storage settings are not provided, it uses the latest local model artifacts from:
    `classifier/local-data/models/`
  - In cloud mode, it loads model artifacts from Blob Storage.
  - Optional: set `uploadOutput=true` to store the inference result under the configured blob prefix (see Storage layout).

### SLA regressor

- **Train**: `POST /api/sla-regressor-lightgbm-train`
  - Trains a Tweedie LightGBM regressor and writes artifacts:
    - `model_*.pkl`, `peaks_*.pkl`, `encodings_*.pkl`, `metrics_*.json`
  - Supports **local** training via `{"localPath":"...","outputLocalDir":"..."}`.
  - Supports **blob** training via `{"container":"...","blob":"...","outputContainer":"...","outputPrefix":"models/"}`.

- **Infer**: `POST /api/sla-regressor-lightgbm-infer`
  - Scores either inline `records` or a blob input table (`container` + `blob`).
  - If `modelBlob`/`peaksBlob`/`encodingsBlob` are omitted, the handler selects the latest artifacts under `modelPrefix`.
  - Returns a preview of predictions and can optionally upload a predictions CSV to blob.

## Project structure

- `function_app.py`: Azure Functions route registration.
- `blob_io.py`: minimal blob I/O helpers (download/upload/latest) using `DefaultAzureCredential`.
- `project_config.py`: loads the unified `config.yaml` (override path via env var).
- `config.yaml`: unified configuration (hold classifier + `sla_regressor:` section).
- `classifier/`
  - `http_handlers.py`: HTTP handlers for hold classifier endpoints.
  - `classifier_process_data.py`: input loading + feature/label preparation.
  - `classifier_train.py`: training + artifact writing.
  - `classifier_infer.py`: artifact loading + scoring.
  - `local-data/`: local-only test data and artifacts (ignored by git and funcignore).
- `sla_regressor/`
  - `http_handlers.py`: HTTP handlers for SLA regressor endpoints.
  - `sla_regressor_process_data.py`: input loading + cleaning + `resolution_minutes` target creation.
  - `sla_regressor_train.py`: feature engineering + training + artifact writing.
  - `sla_regressor_infer.py`: feature engineering + scoring.
  - `local-data/`: local-only test data and artifacts (ignored by git and funcignore).

## Configuration

Primary config now lives in `config.yaml` at the project root.
You can override the path with `HOLD_CLASSIFIER_CONFIG_PATH`.

Set these in `local.settings.json` for local development, or as app settings in Azure (these can still override values where supported):

- `AzureWebJobsStorage`: required by Functions runtime.
- `FUNCTIONS_WORKER_RUNTIME`: `python`
- `STORAGE_ACCOUNT_NAME`: Azure Storage account name.
- `TRAINING_CONTAINER` / `TRAINING_BLOB`: training CSV location in Blob.
- `MODEL_CONTAINER`: container to store model artifacts.
- `MODEL_PREFIX`: artifact prefix/folder (default: `models/`).
- `HOLD_MINUTES_COL`: training label column (default: `HoldTimeInMinutes`).
- `HOLD_CLASSIFIER_THRESHOLD`: inference threshold (default: `0.5`).

SLA regressor endpoints also support namespaced overrides (fallback to the generic env vars when not set).
Both `SLA_REGRESSOR_*` and the older `REGRESSOR_*` names are accepted:

- `SLA_REGRESSOR_TRAINING_CONTAINER` / `SLA_REGRESSOR_TRAINING_BLOB`
- `SLA_REGRESSOR_MODEL_CONTAINER` / `SLA_REGRESSOR_MODEL_PREFIX`
- `SLA_REGRESSOR_OUTPUT_CONTAINER` / `SLA_REGRESSOR_OUTPUT_PREFIX` / `SLA_REGRESSOR_OUTPUT_PREFIX_PRED`

## Storage layout (recommended)

All blobs live under the configured container (default: `train-data`) and are organized by prefixes:

### Hold classifier

- **Training inputs**: `hold-classifier/training-data/`
- **Model artifacts**: `hold-classifier/models/`
- **Inference outputs** (optional): `hold-classifier/inference-outputs/`

### SLA regressor (LightGBM)

- **Training inputs**: `sla-regressor-lightgbm/training-data/`
- **Model artifacts**: `sla-regressor-lightgbm/models/`
- **Inference outputs**: `sla-regressor-lightgbm/inference-outputs/`

Blob auth uses `DefaultAzureCredential` (Managed Identity in Azure). For local blob access, use `az login`.

## Run locally (Windows / PowerShell)

Prereqs: Python 3.x and Azure Functions Core Tools.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r .\requirements.txt
$PORT = 7075
func start --port $PORT
```

## Local testing flow

1. Keep test inputs under `classifier/local-data/` or `sla_regressor/local-data/`.
2. Train hold classifier locally:

```powershell
curl.exe -X POST "http://localhost:$PORT/api/hold-classifier-lightGBM-train" -H "Content-Type: application/json" -d "{}"
```

2b. Train all models locally (recommended during dev):

```powershell
$body = @{
  localPath       = "dataset/Cases_CompleteSet_ActualTime-excel.xlsx"
  parallel        = $true
  holdMinutesCol  = "HoldTimeInMinutes"
  pretty          = $true
} | ConvertTo-Json -Depth 20 -Compress

curl.exe -X POST "http://localhost:$PORT/api/case-sla-lightgbm-train-all" `
  -H "Content-Type: application/json" `
  -d $body
```

3. Infer hold classifier using a sample body file:

```powershell
curl.exe -X POST "http://localhost:$PORT/api/hold-classifier-lightGBM-infer" -H "Content-Type: application/json" -d "@classifier/local-data/body-infer-sample-1.json"
```

4. (Optional) Train SLA regressor locally from a CSV/XLSX:

```powershell
curl.exe -X POST "http://localhost:$PORT/api/sla-regressor-lightgbm-train" -H "Content-Type: application/json" -d "{\"localPath\":\"sla_regressor/local-data/train.csv\",\"outputLocalDir\":\"sla_regressor/local-data/models\"}"
```

## Notes

- Local-only artifacts live under `classifier/local-data/` and `sla_regressor/local-data/` (ignored by both `.gitignore` and `.funcignore`).
- If your terminal output looks corrupted/truncated after training, use the **artifact metrics files** as the source of truth:
  - Hold classifier: `classifier/local-data/models/*_meta_*.json`
  - Hold regressor: `hold_regressor/local-data/models/*_meta_*.json`
  - SLA regressor: `sla_regressor/local-data/models/metrics.json`
- Storage-management HTTP APIs (`/api/storage-access/*`) were removed from this Function App and migrated to a dedicated storage Function App (keep this service focused on ML endpoints).
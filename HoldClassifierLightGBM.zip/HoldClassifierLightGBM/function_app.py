import azure.functions as func

from classifier.http_handlers import (
    handle_hold_classifier_lightgbm_infer,
    handle_hold_classifier_lightgbm_train,
)
from sla_regressor.http_handlers import (
    handle_sla_regressor_lightgbm_infer,
    handle_sla_regressor_lightgbm_train,
)
from hold_regressor.http_handlers import (
    handle_hold_regressor_lightgbm_infer,
    handle_hold_regressor_lightgbm_train,
)
from case_http_handlers import handle_case_sla_lightgbm_infer
from train_all_http_handlers import handle_case_sla_lightgbm_train_all

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.function_name(name="hold-classifier-lightGBM-train")
@app.route(route="hold-classifier-lightGBM-train", methods=["POST"])
def hold_classifier_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    return handle_hold_classifier_lightgbm_train(req)


@app.function_name(name="hold-classifier-lightGBM-infer")
@app.route(route="hold-classifier-lightGBM-infer", methods=["POST"])
def hold_classifier_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    return handle_hold_classifier_lightgbm_infer(req)


@app.function_name(name="sla-regressor-lightgbm-train")
@app.route(route="sla-regressor-lightgbm-train", methods=["POST"])
def sla_regressor_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    return handle_sla_regressor_lightgbm_train(req)


@app.function_name(name="sla-regressor-lightgbm-infer")
@app.route(route="sla-regressor-lightgbm-infer", methods=["POST"])
def sla_regressor_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    return handle_sla_regressor_lightgbm_infer(req)


@app.function_name(name="hold-regressor-lightgbm-train")
@app.route(route="hold-regressor-lightgbm-train", methods=["POST"])
def hold_regressor_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    return handle_hold_regressor_lightgbm_train(req)


@app.function_name(name="hold-regressor-lightgbm-infer")
@app.route(route="hold-regressor-lightgbm-infer", methods=["POST"])
def hold_regressor_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    return handle_hold_regressor_lightgbm_infer(req)


@app.function_name(name="case-sla-lightgbm-infer")
@app.route(route="case-sla-lightgbm-infer", methods=["POST"])
def case_sla_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    return handle_case_sla_lightgbm_infer(req)


@app.function_name(name="case-sla-lightgbm-train-all")
@app.route(route="case-sla-lightgbm-train-all", methods=["POST"])
def case_sla_lightgbm_train_all(req: func.HttpRequest) -> func.HttpResponse:
    return handle_case_sla_lightgbm_train_all(req)
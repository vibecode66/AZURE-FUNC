import datetime
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

import azure.functions as func

from blob_io import download_blob_to_file, latest_blob
from classifier.classifier_infer import infer_from_artifacts as infer_hold_classifier_from_artifacts
from hold_regressor.hold_regressor_infer import infer_from_artifacts as infer_hold_minutes_from_artifacts
from project_config import cfg_get
from sla_regressor.sla_regressor_infer import artifacts_from_files, predict_df


DEFAULT_STORAGE_ACCOUNT = str(cfg_get("storage.account_name", "stslalightgbmuateu"))
DEFAULT_CONTAINER = str(cfg_get("storage.default_container", "train-data"))


def _is_local_runtime() -> bool:
    return not bool(os.getenv("WEBSITE_INSTANCE_ID"))


def _resolve_local_dir(cfg_key: str, default_rel: str) -> Path:
    p = Path(str(cfg_get(cfg_key, default_rel)))
    if p.is_absolute():
        return p
    return Path(__file__).resolve().parent / p


def _latest_local_artifact(models_dir: Path, prefix: str, suffix: str) -> Path | None:
    if not models_dir.exists():
        return None
    matches = sorted(models_dir.glob(f"{prefix}*{suffix}"), key=lambda p: p.stat().st_mtime)
    return matches[-1] if matches else None


def _json_response(obj, status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(obj),
        status_code=status_code,
        mimetype="application/json",
    )


def handle_case_sla_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    """
    Composite inference:
      1) Hold classifier: predict hold probability + is_hold
      2) If hold: hold regressor predicts hold minutes
      3) SLA regressor predicts resolution datetime/minutes
      4) Return combined payload including adjusted SLA (SLA + hold minutes when hold)

    POST JSON body supports:
      - record: object OR flat object
      - threshold: hold-classifier threshold (default config/env)
      - storageAccount/container: used for artifact blobs (default config/env)
      - model containers/prefixes/blob overrides per sub-model
    """
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    record = body.get("record") if isinstance(body, dict) else None
    if record is None:
        record = body
    if not isinstance(record, dict) or not record:
        return _json_response({"error": "Missing input record (JSON object)."}, status_code=400)

    storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME") or DEFAULT_STORAGE_ACCOUNT
    container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER

    # ---------------------------------------------------------------------
    # 1) Hold classifier
    # ---------------------------------------------------------------------
    threshold = (
        body.get("threshold")
        or os.getenv("HOLD_CLASSIFIER_THRESHOLD")
        or str(cfg_get("inference.threshold", 0.5))
    )
    try:
        threshold_f = float(threshold)
    except Exception:
        threshold_f = 0.5

    hold_model_container = (
        body.get("holdClassifierModelContainer")
        or body.get("modelContainer")
        or os.getenv("MODEL_CONTAINER")
        or container
    )
    hold_model_prefix = (
        body.get("holdClassifierModelPrefix")
        or body.get("modelPrefix")
        or os.getenv("MODEL_PREFIX")
        or str(cfg_get("training.model_prefix", "hold-classifier/models/"))
    ).rstrip("/") + "/"
    hold_model_blob = body.get("holdClassifierModelBlob")
    hold_meta_blob = body.get("holdClassifierMetaBlob")

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    explicit_hold_storage = bool(body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME"))
    explicit_hold_container = bool(body.get("holdClassifierModelContainer") or body.get("modelContainer") or os.getenv("MODEL_CONTAINER"))
    use_local_hold_classifier = _is_local_runtime() and (not explicit_hold_storage or not explicit_hold_container)

    if use_local_hold_classifier:
        local_dir = _resolve_local_dir("paths.local_data_dir", "classifier/local-data")
        models_dir = local_dir / "models"
        hold_model_local = _latest_local_artifact(models_dir, "hold_classifier_model_", ".txt")
        hold_meta_local = _latest_local_artifact(models_dir, "hold_classifier_meta_", ".json")
        if not hold_model_local or not hold_meta_local:
            return _json_response(
                {
                    "status": "error",
                    "stage": "hold_classifier",
                    "message": (
                        "No local hold-classifier artifacts found under classifier/local-data/models. "
                        "Run local training first or provide storage settings."
                    ),
                },
                status_code=400,
            )
        hold_model_info = {"localModel": str(hold_model_local), "localMeta": str(hold_meta_local)}
    else:
        if not hold_model_blob:
            hold_model_blob = latest_blob(storage_account, hold_model_container, f"{hold_model_prefix}hold_classifier_model_")
        if not hold_meta_blob:
            hold_meta_blob = latest_blob(storage_account, hold_model_container, f"{hold_model_prefix}hold_classifier_meta_")

        hold_model_local = Path(tempfile.gettempdir()) / f"hold_classifier_model_{ts}.txt"
        hold_meta_local = Path(tempfile.gettempdir()) / f"hold_classifier_meta_{ts}.json"
        hold_model_info = {"container": hold_model_container, "modelBlob": hold_model_blob, "metaBlob": hold_meta_blob}

    try:
        if not use_local_hold_classifier:
            download_blob_to_file(storage_account, hold_model_container, str(hold_model_blob), hold_model_local)
            download_blob_to_file(storage_account, hold_model_container, str(hold_meta_blob), hold_meta_local)
        hold_prob, is_hold = infer_hold_classifier_from_artifacts(
            record=record,
            model_path=str(hold_model_local),
            meta_path=str(hold_meta_local),
            threshold=threshold_f,
        )
    except Exception as exc:
        logging.exception("Composite infer: hold classifier failed")
        return _json_response({"status": "error", "stage": "hold_classifier", "message": str(exc)}, status_code=500)

    # ---------------------------------------------------------------------
    # 2) Hold regressor (only when predicted hold)
    # ---------------------------------------------------------------------
    hold_minutes = None
    hold_regressor_model_info: dict[str, Any] | None = None
    if int(is_hold) == 1:
        hr_model_container = (
            body.get("holdRegressorModelContainer")
            or os.getenv("HOLD_REGRESSOR_MODEL_CONTAINER")
            or os.getenv("MODEL_CONTAINER")
            or container
        )
        hr_model_prefix = (
            body.get("holdRegressorModelPrefix")
            or os.getenv("HOLD_REGRESSOR_MODEL_PREFIX")
            or os.getenv("MODEL_PREFIX")
            or str(cfg_get("hold_regressor.blob.model_prefix", "hold-regressor-lightgbm/models/"))
        ).rstrip("/") + "/"
        hr_model_blob = body.get("holdRegressorModelBlob")
        hr_meta_blob = body.get("holdRegressorMetaBlob")

        explicit_hr_storage = bool(body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME"))
        explicit_hr_container = bool(body.get("holdRegressorModelContainer") or os.getenv("HOLD_REGRESSOR_MODEL_CONTAINER") or os.getenv("MODEL_CONTAINER"))
        use_local_hold_regressor = _is_local_runtime() and (not explicit_hr_storage or not explicit_hr_container)

        if use_local_hold_regressor:
            local_dir = _resolve_local_dir("paths.local_hold_regressor_data_dir", "hold_regressor/local-data")
            models_dir = local_dir / "models"
            hr_model_local = _latest_local_artifact(models_dir, "hold_regressor_model_", ".pkl")
            hr_meta_local = _latest_local_artifact(models_dir, "hold_regressor_meta_", ".json")
            if not hr_model_local or not hr_meta_local:
                return _json_response(
                    {
                        "status": "error",
                        "stage": "hold_regressor",
                        "message": (
                            "No local hold-regressor artifacts found under hold_regressor/local-data/models. "
                            "Run local training first or provide storage settings."
                        ),
                    },
                    status_code=400,
                )
            hold_regressor_model_info = {"localModel": str(hr_model_local), "localMeta": str(hr_meta_local)}
        else:
            if not hr_model_blob:
                hr_model_blob = latest_blob(storage_account, hr_model_container, f"{hr_model_prefix}hold_regressor_model_")
            if not hr_meta_blob:
                hr_meta_blob = latest_blob(storage_account, hr_model_container, f"{hr_model_prefix}hold_regressor_meta_")

            hr_model_local = Path(tempfile.gettempdir()) / f"hold_regressor_model_{ts}.pkl"
            hr_meta_local = Path(tempfile.gettempdir()) / f"hold_regressor_meta_{ts}.json"
            hold_regressor_model_info = {
                "container": hr_model_container,
                "modelBlob": hr_model_blob,
                "metaBlob": hr_meta_blob,
            }

        try:
            if not use_local_hold_regressor:
                download_blob_to_file(storage_account, hr_model_container, str(hr_model_blob), hr_model_local)
                download_blob_to_file(storage_account, hr_model_container, str(hr_meta_blob), hr_meta_local)
            hold_minutes = float(
                infer_hold_minutes_from_artifacts(
                    record=record,
                    model_path=str(hr_model_local),
                    meta_path=str(hr_meta_local),
                )
            )
        except Exception as exc:
            logging.exception("Composite infer: hold regressor failed")
            return _json_response({"status": "error", "stage": "hold_regressor", "message": str(exc)}, status_code=500)

    # ---------------------------------------------------------------------
    # 3) SLA regressor
    # ---------------------------------------------------------------------
    try:
        local_sla_dir = _resolve_local_dir("paths.local_sla_regressor_data_dir", "sla_regressor/local-data")
        local_sla_models_dir = local_sla_dir / "models"
        local_model = local_sla_models_dir / "model.pkl"
        local_peaks = local_sla_models_dir / "peaks.pkl"
        local_enc = local_sla_models_dir / "encodings.pkl"

        # Local-first: if running locally and local artifacts exist, avoid blob access.
        use_local_sla = _is_local_runtime() and local_model.exists() and local_peaks.exists() and local_enc.exists()

        if use_local_sla:
            artifacts = artifacts_from_files(
                model_path=str(local_model),
                peaks_path=str(local_peaks),
                encodings_path=str(local_enc),
            )
            sla_model_info: dict[str, Any] = {"localDir": str(local_sla_models_dir)}
        else:
            sla_model_container = (
                body.get("slaModelContainer")
                or os.getenv("SLA_REGRESSOR_MODEL_CONTAINER")
                or os.getenv("REGRESSOR_MODEL_CONTAINER")
                or os.getenv("MODEL_CONTAINER")
                or container
            )
            sla_model_prefix = (
                body.get("slaModelPrefix")
                or os.getenv("SLA_REGRESSOR_MODEL_PREFIX")
                or os.getenv("REGRESSOR_MODEL_PREFIX")
                or os.getenv("MODEL_PREFIX")
                or str(cfg_get("sla_regressor.blob.model_prefix", "sla-regressor-lightgbm/models/"))
            ).rstrip("/") + "/"

            sla_model_blob = body.get("slaModelBlob")
            sla_peaks_blob = body.get("slaPeaksBlob")
            sla_enc_blob = body.get("slaEncodingsBlob")
            if not sla_model_blob:
                sla_model_blob = latest_blob(storage_account, sla_model_container, f"{sla_model_prefix}model_")
            if not sla_peaks_blob:
                sla_peaks_blob = latest_blob(storage_account, sla_model_container, f"{sla_model_prefix}peaks_")
            if not sla_enc_blob:
                sla_enc_blob = latest_blob(storage_account, sla_model_container, f"{sla_model_prefix}encodings_")

            sla_model_local = Path(tempfile.gettempdir()) / f"sla_model_{ts}.pkl"
            sla_peaks_local = Path(tempfile.gettempdir()) / f"sla_peaks_{ts}.pkl"
            sla_enc_local = Path(tempfile.gettempdir()) / f"sla_enc_{ts}.pkl"

            download_blob_to_file(storage_account, sla_model_container, str(sla_model_blob), sla_model_local)
            download_blob_to_file(storage_account, sla_model_container, str(sla_peaks_blob), sla_peaks_local)
            download_blob_to_file(storage_account, sla_model_container, str(sla_enc_blob), sla_enc_local)

            artifacts = artifacts_from_files(
                model_path=str(sla_model_local),
                peaks_path=str(sla_peaks_local),
                encodings_path=str(sla_enc_local),
            )
            sla_model_info = {
                "container": sla_model_container,
                "modelBlob": sla_model_blob,
                "peaksBlob": sla_peaks_blob,
                "encodingsBlob": sla_enc_blob,
            }

        import pandas as pd

        df_in = pd.DataFrame([record])
        out_df, full_df = predict_df(df_in, artifacts)
        sla_minutes = float(full_df["predicted_resolution_minutes"].iloc[0])
        sla_dt = str(full_df["predicted_resolution_dt"].iloc[0])
    except Exception as exc:
        logging.exception("Composite infer: SLA regressor failed")
        return _json_response({"status": "error", "stage": "sla_regressor", "message": str(exc)}, status_code=500)

    # ---------------------------------------------------------------------
    # 4) Combine
    # ---------------------------------------------------------------------
    adjusted_sla_minutes = sla_minutes + (float(hold_minutes) if (hold_minutes is not None and int(is_hold) == 1) else 0.0)

    case_sla_dt = None
    # Prefer deriving case SLA dt from SLA dt (already computed by SLA model code),
    # to avoid strict parsing issues on incoming createdon formats.
    try:
        import pandas as pd

        sla_dt_parsed = pd.to_datetime(sla_dt, errors="coerce")
        if pd.notna(sla_dt_parsed):
            extra_hold = float(hold_minutes) if (hold_minutes is not None and int(is_hold) == 1) else 0.0
            case_sla_dt = (sla_dt_parsed + pd.to_timedelta(extra_hold, unit="m")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        case_sla_dt = None

    resp: dict[str, Any] = {
        "status": "ok",
        "ticketNumber": record.get("TicketNumber"),
        "hold": {
            "predicted_hold_probability": round(float(hold_prob), 6),
            "predicted_is_hold_case": int(is_hold),
            "threshold": float(threshold_f),
            "predicted_hold_minutes": round(float(hold_minutes), 3) if hold_minutes is not None else None,
        },
        "sla": {
            "predicted_resolution_minutes": round(float(sla_minutes), 3),
            "predicted_resolution_dt": sla_dt,
        },
        "case_sla": {
            "predicted_case_sla_minutes": round(float(adjusted_sla_minutes), 3),
            "predicted_case_sla_dt": case_sla_dt,
        },
        "models": {
            "hold_classifier": hold_model_info,
            "hold_regressor": hold_regressor_model_info,
            "sla_regressor": sla_model_info,
        },
    }
    return _json_response(resp)


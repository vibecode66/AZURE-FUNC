import base64
import datetime
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

import azure.functions as func

from blob_io import download_blob_to_file, latest_blob, upload_file_to_blob
from classifier.classifier_process_data import read_training_table
from hold_regressor.hold_regressor_infer import infer_from_artifacts
from hold_regressor.hold_regressor_train import train_and_save
from project_config import cfg_get


DEFAULT_STORAGE_ACCOUNT = str(cfg_get("storage.account_name", "stslalightgbmuateu"))
DEFAULT_CONTAINER = str(cfg_get("storage.default_container", "train-data"))
DEFAULT_MODEL_PREFIX = str(cfg_get("hold_regressor.blob.model_prefix", "hold-regressor-lightgbm/models/"))
DEFAULT_TRAINING_DATA_PREFIX = str(
    cfg_get("hold_regressor.blob.training_data_prefix", "hold-regressor-lightgbm/training-data/")
)


def _is_local_runtime() -> bool:
    return not bool(os.getenv("WEBSITE_INSTANCE_ID"))


def _local_data_dir() -> Path:
    cfg_path = str(cfg_get("paths.local_hold_regressor_data_dir", "hold_regressor/local-data"))
    p = Path(cfg_path)
    if p.is_absolute():
        return p
    return Path(__file__).resolve().parents[1] / p


def _latest_local_artifact(prefix: str, suffix: str) -> Path | None:
    models_dir = _local_data_dir() / "models"
    if not models_dir.exists():
        return None
    matches = sorted(models_dir.glob(f"{prefix}*{suffix}"), key=lambda p: p.stat().st_mtime)
    return matches[-1] if matches else None


def _json_response(obj, status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(obj),
        status_code=status_code,
        mimetype="application/json",
    )


def _extract_uploaded_file(req: func.HttpRequest, body: dict):
    if hasattr(req, "files") and req.files:
        uploaded = req.files.get("file")
        if uploaded:
            return uploaded.filename, uploaded.read()

    file_name = body.get("fileName")
    file_b64 = body.get("fileBase64")
    if file_name and file_b64:
        return file_name, base64.b64decode(file_b64)
    return None, None


def handle_hold_regressor_lightgbm_train(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    hold_minutes_col = (
        body.get("holdMinutesCol")
        or os.getenv("HOLD_MINUTES_COL")
        or str(cfg_get("training.hold_minutes_col", "HoldTimeInMinutes"))
    )

    upload_name, upload_bytes = _extract_uploaded_file(req, body)
    if upload_name and upload_bytes:
        storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME") or DEFAULT_STORAGE_ACCOUNT
        container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
        training_prefix = (
            body.get("trainingDataPrefix")
            or os.getenv("HOLD_REGRESSOR_TRAINING_DATA_PREFIX")
            or DEFAULT_TRAINING_DATA_PREFIX
        ).rstrip("/") + "/"
        ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        safe_name = Path(upload_name).name
        uploaded_local = Path(tempfile.gettempdir()) / f"uploaded_holdreg_train_{ts}_{safe_name}"
        with open(uploaded_local, "wb") as f:
            f.write(upload_bytes)
        uploaded_blob = f"{training_prefix}{ts}_{safe_name}"
        upload_file_to_blob(storage_account, container, uploaded_blob, uploaded_local)
        body["storageAccount"] = storage_account
        body["container"] = container
        body["blob"] = uploaded_blob

    local_path = body.get("localPath")
    if local_path:
        if not _is_local_runtime():
            return _json_response(
                {"error": "localPath is only supported when running locally (not in Azure)."},
                status_code=400,
            )
        src_path = Path(str(local_path))
        if not src_path.exists():
            return _json_response({"error": f"localPath does not exist: {src_path}"}, status_code=400)
        try:
            df = read_training_table(src_path)
            out_dir = _local_data_dir() / "models"
            out_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            model_path = out_dir / f"hold_regressor_model_{ts}.pkl"
            meta_path = out_dir / f"hold_regressor_meta_{ts}.json"
            _model, _features, metrics = train_and_save(
                df,
                dst_model_path=str(model_path),
                dst_meta_path=str(meta_path),
                hold_minutes_col=hold_minutes_col,
                trained_utc=ts,
            )
            return _json_response(
                {
                    "status": "ok",
                    "mode": "local",
                    "input": {"localPath": str(src_path)},
                    "output": {"localDir": str(out_dir), "model": str(model_path), "meta": str(meta_path)},
                    "metrics": metrics,
                }
            )
        except Exception as e:
            logging.exception("Local hold regressor training failed")
            return _json_response({"status": "error", "message": str(e)}, status_code=500)

    storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME") or DEFAULT_STORAGE_ACCOUNT
    container = body.get("container") or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
    blob = body.get("blob") or os.getenv("HOLD_REGRESSOR_TRAINING_BLOB") or os.getenv("TRAINING_BLOB")
    if not blob:
        return _json_response(
            {"error": "Missing training blob. Provide body.blob or set HOLD_REGRESSOR_TRAINING_BLOB/TRAINING_BLOB."},
            status_code=400,
        )

    model_container = body.get("modelContainer") or os.getenv("HOLD_REGRESSOR_MODEL_CONTAINER") or os.getenv("MODEL_CONTAINER") or container
    model_prefix = (
        body.get("modelPrefix")
        or os.getenv("HOLD_REGRESSOR_MODEL_PREFIX")
        or os.getenv("MODEL_PREFIX")
        or DEFAULT_MODEL_PREFIX
    ).rstrip("/") + "/"

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    if _is_local_runtime():
        tmp_dir = _local_data_dir() / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        train_local = tmp_dir / f"holdreg_train_{ts}_{Path(blob).name}"
        out_dir = tmp_dir
    else:
        train_local = Path(tempfile.gettempdir()) / f"holdreg_train_{ts}_{Path(blob).name}"
        out_dir = Path(tempfile.mkdtemp(prefix="hold_regressor_artifacts_"))

    model_local = out_dir / f"hold_regressor_model_{ts}.pkl"
    meta_local = out_dir / f"hold_regressor_meta_{ts}.json"

    try:
        logging.info("Downloading hold regressor training data from blob: %s/%s", container, blob)
        download_blob_to_file(storage_account, container, blob, train_local)

        df = read_training_table(train_local)
        _model, _features, metrics = train_and_save(
            df,
            dst_model_path=str(model_local),
            dst_meta_path=str(meta_local),
            hold_minutes_col=hold_minutes_col,
            trained_utc=ts,
        )

        model_blob = f"{model_prefix}hold_regressor_model_{ts}.pkl"
        meta_blob = f"{model_prefix}hold_regressor_meta_{ts}.json"

        logging.info("Uploading hold regressor artifacts to blob container: %s", model_container)
        upload_file_to_blob(storage_account, model_container, model_blob, model_local)
        upload_file_to_blob(storage_account, model_container, meta_blob, meta_local)

        return _json_response(
            {
                "status": "ok",
                "storageAccount": storage_account,
                "input": {"container": container, "blob": blob},
                "output": {"container": model_container, "modelBlob": model_blob, "metaBlob": meta_blob},
                "metrics": metrics,
            }
        )
    except Exception as e:
        logging.exception("Hold regressor training failed")
        return _json_response({"status": "error", "message": str(e)}, status_code=500)


def handle_hold_regressor_lightgbm_infer(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    record = body.get("record") if isinstance(body, dict) else None
    if record is None:
        record = body
    if not isinstance(record, dict) or not record:
        return _json_response({"error": "Missing input record (JSON object)."}, status_code=400)

    explicit_storage_account = body.get("storageAccount") or os.getenv("STORAGE_ACCOUNT_NAME")
    explicit_model_container = body.get("modelContainer") or os.getenv("HOLD_REGRESSOR_MODEL_CONTAINER") or os.getenv("MODEL_CONTAINER")
    storage_account = explicit_storage_account or DEFAULT_STORAGE_ACCOUNT
    model_container = explicit_model_container or os.getenv("TRAINING_CONTAINER") or DEFAULT_CONTAINER
    use_local_artifacts = _is_local_runtime() and (not explicit_storage_account or not explicit_model_container)

    if use_local_artifacts:
        model_local = _latest_local_artifact("hold_regressor_model_", ".pkl")
        meta_local = _latest_local_artifact("hold_regressor_meta_", ".json")
        if not model_local or not meta_local:
            return _json_response(
                {
                    "error": (
                        "No local hold regressor artifacts found in hold_regressor/local-data/models. "
                        "Run local training first."
                    )
                },
                status_code=400,
            )
        try:
            pred_minutes = infer_from_artifacts(
                record=record,
                model_path=str(model_local),
                meta_path=str(meta_local),
            )
            resp: dict[str, Any] = {
                "status": "ok",
                "mode": "local",
                "ticketNumber": record.get("TicketNumber"),
                "predicted_hold_minutes": round(float(pred_minutes), 3),
                "model": {"localModel": str(model_local), "localMeta": str(meta_local)},
            }
            return _json_response(resp)
        except Exception as e:
            logging.exception("Hold regressor inference failed (local artifacts)")
            return _json_response({"status": "error", "message": str(e)}, status_code=500)

    model_prefix = (
        body.get("modelPrefix")
        or os.getenv("HOLD_REGRESSOR_MODEL_PREFIX")
        or os.getenv("MODEL_PREFIX")
        or DEFAULT_MODEL_PREFIX
    ).rstrip("/") + "/"
    model_blob = body.get("modelBlob")
    meta_blob = body.get("metaBlob")

    if not model_blob:
        model_blob = latest_blob(storage_account, model_container, f"{model_prefix}hold_regressor_model_")
    if not meta_blob:
        meta_blob = latest_blob(storage_account, model_container, f"{model_prefix}hold_regressor_meta_")

    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    if _is_local_runtime():
        tmp_dir = _local_data_dir() / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        model_local = tmp_dir / f"holdreg_model_{ts}.pkl"
        meta_local = tmp_dir / f"holdreg_meta_{ts}.json"
    else:
        model_local = Path(tempfile.gettempdir()) / f"holdreg_model_{ts}.pkl"
        meta_local = Path(tempfile.gettempdir()) / f"holdreg_meta_{ts}.json"

    try:
        logging.info("Downloading hold regressor artifacts: %s | %s", model_blob, meta_blob)
        download_blob_to_file(storage_account, model_container, model_blob, model_local)
        download_blob_to_file(storage_account, model_container, meta_blob, meta_local)

        pred_minutes = infer_from_artifacts(
            record=record,
            model_path=str(model_local),
            meta_path=str(meta_local),
        )

        resp: dict[str, Any] = {
            "status": "ok",
            "ticketNumber": record.get("TicketNumber"),
            "predicted_hold_minutes": round(float(pred_minutes), 3),
            "model": {"container": model_container, "modelBlob": model_blob, "metaBlob": meta_blob},
        }
        return _json_response(resp)
    except Exception as e:
        logging.exception("Hold regressor inference failed")
        return _json_response({"status": "error", "message": str(e)}, status_code=500)


"""
Hold regression (hold-time) Azure Functions components.

Structure mirrors other model packages:
- `hold_regressor_process_data.py`
- `hold_regressor_train.py`
- `hold_regressor_infer.py`
"""


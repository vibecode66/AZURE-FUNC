from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import pandas as pd

from classifier.classifier_process_data import read_training_table
from project_config import get_config


HOLD_REGRESSOR_FEATURES = [
    # Reference implementation uses this minimal set; keep as default and
    # allow extra features via the global `features.preferred` if present.
    "msdyn_casetypeidname",
    "msdyn_casesubtypeidname",
    "msdyn_casereasonidname",
    "msdyn_casesubreasonidname",
    "msdyn_complexityname",
    "prioritycodename",
    "msdyn_businessfunctionidname",
    "msdyn_countrysubmitteridname",
    "msdyn_caserocname",
]


def load_config() -> Dict[str, Any]:
    """
    Load the hold regressor config from the unified project `config.yaml` (top-level),
    under the `hold_regressor:` key.
    """
    unified = get_config()
    hold_reg = unified.get("hold_regressor")
    if not isinstance(hold_reg, dict) or not hold_reg:
        raise FileNotFoundError(
            "Missing hold regressor config. Expected a non-empty `hold_regressor:` section in the unified project config.yaml."
        )
    return hold_reg


def _coerce_minutes(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def pick_features(df: pd.DataFrame, *, cfg: Dict[str, Any] | None = None) -> list[str]:
    """
    Hold regressor features:
    - Prefer the reference hold feature list when present
    - If `features.preferred` exists in unified config, include any of those columns too (when present)
    """
    cfg = cfg or get_config()
    preferred = cfg.get("features", {}).get("preferred") if isinstance(cfg.get("features"), dict) else None
    if not isinstance(preferred, list):
        preferred = []

    wanted = list(dict.fromkeys([*HOLD_REGRESSOR_FEATURES, *[str(x) for x in preferred]]))
    return [c for c in wanted if c in df.columns]


def prepare_hold_minutes_target(df: pd.DataFrame, *, hold_minutes_col: str) -> pd.DataFrame:
    df = df.copy()
    if hold_minutes_col not in df.columns:
        raise ValueError(f"Missing required column: {hold_minutes_col}")
    df[hold_minutes_col] = _coerce_minutes(df[hold_minutes_col])
    df["target_hold_minutes"] = df[hold_minutes_col].fillna(0)
    df["is_hold_case"] = (df["target_hold_minutes"] > 0).astype(int)
    return df


def load_training_table(path: Path) -> pd.DataFrame:
    return read_training_table(path)


def prepare_regression_training_data(
    df: pd.DataFrame,
    *,
    hold_minutes_col: str,
    cfg: Dict[str, Any] | None = None,
) -> tuple[pd.DataFrame, pd.Series, list[str], pd.DataFrame]:
    """
    Returns:
      - X_reg (feature frame for regressor, hold cases only)
      - y_reg (hold minutes)
      - features
      - df_labeled (df with is_hold_case/target_hold_minutes)
    """
    cfg = cfg or get_config()
    df_labeled = prepare_hold_minutes_target(df, hold_minutes_col=hold_minutes_col)

    hold_cases = df_labeled[df_labeled["is_hold_case"] == 1].copy()
    if len(hold_cases) == 0:
        raise ValueError("No hold cases found (hold minutes > 0). Cannot train hold regressor.")

    features = pick_features(hold_cases, cfg=cfg)
    if not features:
        raise ValueError("No usable feature columns found in the dataset for hold regression.")

    for col in features:
        hold_cases[col] = hold_cases[col].fillna("Unknown").astype("category")

    X_reg = hold_cases[features]
    y_reg = hold_cases["target_hold_minutes"]
    return X_reg, y_reg, features, df_labeled


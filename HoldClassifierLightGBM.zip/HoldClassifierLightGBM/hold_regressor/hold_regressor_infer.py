from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Tuple

import joblib
import numpy as np
import pandas as pd


def load_model_artifacts(model_path: str, meta_path: str) -> Tuple[Any, list[str], Dict[str, Any]]:
    model = joblib.load(model_path)
    meta = json.loads(Path(meta_path).read_text(encoding="utf-8"))
    features = list(meta.get("features") or [])
    if not features:
        raise ValueError("Model metadata missing 'features'.")
    return model, features, meta


def predict_hold_minutes(model: Any, features: list[str], payload: Dict[str, Any]) -> float:
    row = {f: payload.get(f, "Unknown") for f in features}
    X = pd.DataFrame([row])
    for col in features:
        X[col] = X[col].fillna("Unknown").astype("category")
    pred = float(model.predict(X[features])[0])
    return float(np.clip(pred, 0.0, None))


def infer_from_loaded(
    model: Any,
    features: list[str],
    *,
    record: Dict[str, Any],
) -> float:
    return predict_hold_minutes(model, features, record)


def infer_from_artifacts(
    *,
    record: Dict[str, Any],
    model_path: str,
    meta_path: str,
) -> float:
    model, features, _meta = load_model_artifacts(model_path, meta_path)
    return infer_from_loaded(model, features, record=record)


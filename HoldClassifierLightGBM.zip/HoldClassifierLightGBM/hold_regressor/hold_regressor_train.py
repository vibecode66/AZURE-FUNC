from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Tuple

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

from hold_regressor.hold_regressor_process_data import prepare_regression_training_data
from project_config import cfg_get


@dataclass(frozen=True)
class TrainArtifacts:
    model: Any
    features: list[str]
    metrics: Dict[str, Any]


def train_hold_regressor(
    df: pd.DataFrame,
    *,
    hold_minutes_col: str,
    random_state: int,
) -> TrainArtifacts:
    X_reg, y_reg, features, _df_labeled = prepare_regression_training_data(
        df, hold_minutes_col=hold_minutes_col
    )

    X_train, X_test, y_train, y_test = train_test_split(
        X_reg, y_reg, test_size=0.2, random_state=random_state
    )

    # Keep params conservative and consistent with reference approach.
    model = lgb.LGBMRegressor(
        objective=str(cfg_get("hold_regressor.training.objective", "tweedie")),
        metric=str(cfg_get("hold_regressor.training.metric", "mae")),
        random_state=random_state,
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    preds = np.clip(preds.astype(float), 0.0, None)

    metrics: Dict[str, Any] = {
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "mae": float(mean_absolute_error(y_test, preds)),
        "r2": float(r2_score(y_test, preds)) if len(y_test) > 1 else float("nan"),
        "hold_minutes_col": hold_minutes_col,
    }
    return TrainArtifacts(model=model, features=features, metrics=metrics)


def save_model_artifacts(
    model: Any,
    features: list[str],
    *,
    dst_model_path: str,
    dst_meta_path: str,
    extra_meta: Dict[str, Any] | None = None,
) -> None:
    Path(dst_model_path).parent.mkdir(parents=True, exist_ok=True)
    Path(dst_meta_path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, dst_model_path)
    meta = {"features": list(features)}
    if extra_meta:
        meta.update(extra_meta)
    Path(dst_meta_path).write_text(json.dumps(meta, indent=2), encoding="utf-8")


def train_and_save(
    df: pd.DataFrame,
    *,
    dst_model_path: str,
    dst_meta_path: str,
    hold_minutes_col: str,
    trained_utc: str,
) -> Tuple[Any, list[str], Dict[str, Any]]:
    random_state = int(cfg_get("model.random_state", 42))
    artifacts = train_hold_regressor(
        df,
        hold_minutes_col=hold_minutes_col,
        random_state=random_state,
    )
    save_model_artifacts(
        artifacts.model,
        artifacts.features,
        dst_model_path=dst_model_path,
        dst_meta_path=dst_meta_path,
        extra_meta={"trainedUtc": trained_utc, "metrics": artifacts.metrics},
    )
    return artifacts.model, artifacts.features, artifacts.metrics


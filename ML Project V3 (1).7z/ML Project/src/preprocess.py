import pandas as pd
import numpy as np
import re


def clean_and_engineer(df, quantile_limit=0.75):
    # Target Calculation
    df['received_dt'] = pd.to_datetime(df['msdyn_receiveddate'], errors='coerce')
    df['resolved_dt'] = pd.to_datetime(df['msdyn_resolveddate'], errors='coerce')
    df = df.dropna(subset=['received_dt', 'resolved_dt'])
    df['target_minutes'] = (df['resolved_dt'] - df['received_dt']).dt.total_seconds() / 60

    ####filter (Remove if the time_minutes is less than 30 minutes)
    ########## & (less than 43200 minutes)
    df = df[(df['target_minutes'] > 30) &
            (df['target_minutes'] < 43200)
    ]

    # Feature Engineering
    df['daily_volume'] = df.groupby(df['received_dt'].dt.date)['msdyn_caserocname'].transform('count')
    df['hour_of_day'] = df['received_dt'].dt.hour.astype(str)
    df['day_of_week'] = df['received_dt'].dt.dayofweek.astype(str)

    # Outlier Removal
    upper_limit = df['target_minutes'].quantile(quantile_limit)
    df_clean = df[df['target_minutes'] < upper_limit].copy()

    print("Total records after applying 75th percentile filter:", len(df_clean))
    print("Records removed:", len(df) - len(df_clean))

    # Target Encoding (Historical Median)
    median_map = df_clean.groupby('msdyn_casereasonidname')['target_minutes'].median()
    df_clean['reason_median_speed'] = df_clean['msdyn_casereasonidname'].map(median_map)

    return df_clean, median_map


def clean_categorical_strings(df, cat_cols):
    for col in cat_cols:
        df[col] = (
            df[col]
            .map(lambda x: str(int(x)) if pd.notnull(x) and isinstance(x, (float, int)) else str(x))
            .replace('nan', 'Unknown')
        )
    return df

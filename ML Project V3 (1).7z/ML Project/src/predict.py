import pandas as pd
import numpy as np
import os
from sklearn.metrics import r2_score, mean_absolute_error # Added for metrics

def adjust_for_weekend(dt):
    """Adjusts a datetime if it falls on a Saturday or Sunday."""
    if dt.weekday() == 5:  # Saturday
        return dt + pd.Timedelta(days=2)
    elif dt.weekday() == 6:  # Sunday
        return dt + pd.Timedelta(days=1)
    return dt

def generate_demo_predictions(model, demo_df, top_features, final_cat_features, median_speed_map, global_median, config_path='config.yaml'):
    """Processes demo data and returns predictions with weekend adjustments."""

    # 1. Load YAML Configuration
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    save_path = config['paths']['demo_results']

    # Feature Engineering for Demo
    demo_df['received_dt'] = pd.to_datetime(demo_df['msdyn_receiveddate'], errors='coerce')
    demo_df['hour_of_day'] = demo_df['received_dt'].dt.hour.astype(str)
    demo_df['day_of_week'] = demo_df['received_dt'].dt.dayofweek.astype(str)
    demo_df['daily_volume'] = demo_df.groupby(demo_df['received_dt'].dt.date)['msdyn_caserocname'].transform('count')

    # Target Encoding using map from training
    demo_df['reason_median_speed'] = demo_df['msdyn_casereasonidname'].map(median_speed_map).fillna(global_median)

    # Categorical Cleaning
    for col in final_cat_features:
        demo_df[col] = (
            demo_df[col]
            .map(lambda x: str(int(x)) if pd.notnull(x) and isinstance(x, (float, int)) else str(x))
            .replace('nan', 'Unknown')
        )

    # Predict
    X_demo = demo_df[top_features]
    preds_log = model.predict(X_demo)
    demo_df['predicted_resolution_minutes'] = np.expm1(preds_log)

    # --- METRICS CALCULATION START ---
    # Ensure we drop NaNs for the score calculation if target_minutes contains any
    valid_mask = demo_df['target_minutes'].notnull()
    y_true = demo_df.loc[valid_mask, 'target_minutes']
    y_pred = demo_df.loc[valid_mask, 'predicted_resolution_minutes']

    final_r2 = r2_score(y_true, y_pred)
    final_mae = mean_absolute_error(y_true, y_pred)

    print("-" * 30)
    print(f"Final R2 Score: {final_r2:.4f}")
    print(f"Final MAE:      {final_mae:.2f} minutes")
    print("-" * 30)

    # Error Calculation
    demo_df['prediction_error'] = (demo_df['target_minutes'] - demo_df['predicted_resolution_minutes']).abs()

    # Time Calculation & Weekend Adjustment
    demo_df['msdyn_receiveddate'] = pd.to_datetime(demo_df['msdyn_receiveddate'])
    raw_finish = demo_df['msdyn_receiveddate'] + pd.to_timedelta(demo_df['predicted_resolution_minutes'], unit='m')
    demo_df['predicted_resolved_date'] = raw_finish.apply(adjust_for_weekend)

    # Reorder Columns (Target and Prediction at the front)
    cols = [col for col in demo_df.columns if col not in ['target_minutes', 'predicted_resolution_minutes','prediction_error']]
    ordered_df = demo_df[['target_minutes', 'predicted_resolution_minutes','prediction_error'] + cols]

    # --- Save to CSV based on YAML Path ---
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    ordered_df.to_csv(save_path, index=False)
    print(f"Results successfully saved to: {save_path}")

    return ordered_df

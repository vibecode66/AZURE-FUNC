from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np


def select_top_features(df, candidate_features, categorical_cols, target_col, top_n=8):
    """
    Runs a preliminary model to find the most important features.
    """
    X_temp = df[candidate_features]
    y_temp = np.log1p(df[target_col])

    # Preliminary Model
    selector_model = CatBoostRegressor(iterations=300, cat_features=categorical_cols, verbose=0)
    selector_model.fit(X_temp, y_temp)

    # Calculate Importance
    feat_imp = pd.Series(selector_model.get_feature_importance(), index=candidate_features).sort_values(ascending=False)
    top_features = feat_imp.head(top_n).index.tolist()

    # Identify which of the top features are categorical
    final_cat_features = [f for f in top_features if f in categorical_cols]

    return top_features, final_cat_features

def train_final_model(df, top_features, final_cat_features, target_col, test_size=0.3):
    """
    Trains the optimized model using the selected top features.
    """
    X = df[top_features]
    y = np.log1p(df[target_col])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=40
    )

    final_model = CatBoostRegressor(
        iterations=3000,
        learning_rate=0.015,
        depth=10,
        l2_leaf_reg=12,
        bagging_temperature=0.2,
        loss_function='MAE',
        eval_metric='R2',
        od_type='Iter',
        od_wait=200,
        verbose=100,
        cat_features=final_cat_features
    )

    final_model.fit(X_train, y_train, eval_set=(X_test, y_test))

    return final_model, X_test, y_test


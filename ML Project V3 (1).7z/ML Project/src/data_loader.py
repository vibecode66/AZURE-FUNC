import pandas as pd
import os


def load_raw_data(file_path):
    df = pd.read_excel(file_path, engine='openpyxl')
    df = df.rename(columns={'createdon': 'msdyn_receiveddate'})

    # Initial 2025 Filter
    df['msdyn_receiveddate'] = pd.to_datetime(df['msdyn_receiveddate'], errors='coerce')
    df = df[df['msdyn_receiveddate'].dt.year == 2025].copy()
    print(f"Number of Records for 2025: {len(df)}")

    # Filter for business logic & 2025 data
    df = df[
        (df['msdyn_resolveddate'].notna()) &
        (df['msdyn_caserocname'].notna()) &
        ((df['onholdtime'] == 0) | (df['onholdtime'].isna()))
        ].copy()

    df = df.drop(
        columns=[
            'msdyn_casesubsubreasonidname',
            'msdyn_totalholdtime', 'ticketnumber', 'onholdtime',
            'statuscode'
        ],
        errors='ignore'
    )
    print(f"Number of Records after business filter: {len(df)}")

    return df

